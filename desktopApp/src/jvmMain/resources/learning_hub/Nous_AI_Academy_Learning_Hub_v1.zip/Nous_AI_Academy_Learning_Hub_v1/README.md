# Nous AI Academy Learning Hub Curriculum v1.0.0

This is a complete offline curriculum package for the desktop Learning Hub.

## Included

- 20 ordered AI sections
- 100 original lessons (5 per section)
- 10,000 populated practice problems (100 per lesson), each with an answer or scoring rubric and explanation
- 20 printable PDF practice sheets with answer keys
- Markdown lesson and answer-key sources
- JSON manifests and JSONL problem bank
- SQLite content database with FTS lesson search
- Import contract, checksums, validation report, and agent instructions

No user data, progress data, cloud account, paid API, or network connection is included or required.

## App entrypoints

1. `curriculum.json` - canonical curriculum manifest
2. `database/nous_learning_hub.db` - prebuilt read-only content database
3. `problems/problem_bank_10000.jsonl` - canonical problem stream
4. `schemas/import_contract.json` - safe import and activation rules

The app should store curriculum content separately from the user's writable progress database.
