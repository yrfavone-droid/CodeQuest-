# Agent Implementation Instructions

Implement this package as the only active content inside the Nous AI Academy desktop Learning Hub.

1. Read `schemas/import_contract.json` and `curriculum.json` before changing application code.
2. Treat curriculum files as read-only bundled content. Keep user accounts, progress, notes, bookmarks, and settings in the existing writable local database.
3. Add an importer that copies a new package to a staging directory, verifies every SHA-256 entry in `checksums.sha256`, validates counts and IDs, imports in one transaction, and activates through an atomic version pointer. On any error, leave the previous content active.
4. Display 20 ordered section cards. Each section opens its five lessons, practice, section PDF, and progress state. A lesson displays the Markdown source, then its first ten practice tasks. The full bank is available through adaptive practice.
5. Score multiple-choice and numeric problems automatically. For rubric answers, show the rubric after the learner submits a response and allow self-check: Retry, Needs Review, or Mastered.
6. Do not require Supabase, Vercel, authentication, payment, telemetry, or internet. Update checks may be optional, but the installed curriculum must always work offline.
7. Never run lesson code through the legacy unrestricted ProcessBuilder path. Keep code labs disabled or use an approved isolated runner.
8. Test first launch with no network, upgrade from an earlier local profile, rollback after a corrupted package, search, PDF open/download, progress preservation, and all problem answer types.
9. Report exact tests, screenshots, final package version, and any remaining blocker. Do not replace real content with placeholders or claim success without opening the packaged desktop build.
