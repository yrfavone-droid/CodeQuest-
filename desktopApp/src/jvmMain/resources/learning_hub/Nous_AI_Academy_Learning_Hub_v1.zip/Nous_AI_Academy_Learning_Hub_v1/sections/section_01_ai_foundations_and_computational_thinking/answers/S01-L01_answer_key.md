# Answer Key - S01-L01: AI, Machine Learning, Deep Learning, and Generative AI

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 3

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 4

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 5

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 6

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 7

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 9

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.

## 10

**Answer:** The response should accurately use machine, learning, deep, generative; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Artificial intelligence is the broad goal of creating systems that perform tasks associated with intelligent behavior. Machine learning is one way to achieve that goal by fitting patterns from data; deep learning is machine learning with multilayer neural networks; generative AI produces new outputs such as text or images from learned distributions.

**Why:** A handwritten-digit recognizer is ML; a multilayer convolutional recognizer is DL; a system that creates a new digit image is generative AI.
