# Answer Key - S01-L02: Problem Decomposition and Algorithms

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 3

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 4

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 5

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 6

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 7

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 9

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.

## 10

**Answer:** The response should accurately use problem, decomposition, algorithms, turn; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A useful algorithm is a finite, unambiguous sequence of operations. Decomposition separates a large task into smaller units that can be tested independently.

**Why:** For spam detection, define the message as input, spam/not-spam as output, constraints such as privacy and latency, then separate cleaning, feature creation, prediction, and evaluation.
