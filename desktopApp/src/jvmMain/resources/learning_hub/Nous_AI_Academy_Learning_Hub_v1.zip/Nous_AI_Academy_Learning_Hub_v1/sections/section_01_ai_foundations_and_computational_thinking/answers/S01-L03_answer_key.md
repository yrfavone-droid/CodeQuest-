# Answer Key - S01-L03: Data, Features, Labels, Models, and Inference

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 3

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 4

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 5

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 6

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 7

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 9

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.

## 10

**Answer:** The response should accurately use features, labels, models, inference; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Features are measurable inputs, labels are desired outputs for supervised learning, a model maps features to outputs, training estimates model parameters, and inference applies the trained model to new data.

**Why:** Hours studied and practice accuracy may be features; pass/fail may be a label; a fitted classifier produces a score for a new learner.
