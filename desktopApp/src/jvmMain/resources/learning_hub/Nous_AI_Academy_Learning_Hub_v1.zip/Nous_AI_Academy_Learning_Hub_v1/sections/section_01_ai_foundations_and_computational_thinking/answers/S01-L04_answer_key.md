# Answer Key - S01-L04: Learning Paradigms

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 3

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 4

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 5

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 6

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 7

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 9

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.

## 10

**Answer:** The response should accurately use learning, paradigms, compare, supervised; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Supervised learning uses target labels, unsupervised learning seeks structure without target labels, self-supervised learning creates prediction targets from the data itself, and reinforcement learning improves actions using rewards from interaction.

**Why:** Email classification is supervised, customer grouping is unsupervised, predicting masked words is self-supervised, and learning a game policy from rewards is reinforcement learning.
