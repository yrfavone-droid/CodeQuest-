# Answer Key - S01-L05: Evidence, Reproducibility, and Responsible AI

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 3

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 4

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 5

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 6

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 7

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 9

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.

## 10

**Answer:** The response should accurately use evidence, reproducibility, responsible, treat; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Reliable AI records data provenance, splits, metrics, seeds, assumptions, and failure cases. Responsible development also asks who may be harmed, whose data is represented, and when a human must remain in control.

**Why:** A 95% accuracy claim is incomplete without the test set, class distribution, uncertainty, subgroup results, and a comparison baseline.
