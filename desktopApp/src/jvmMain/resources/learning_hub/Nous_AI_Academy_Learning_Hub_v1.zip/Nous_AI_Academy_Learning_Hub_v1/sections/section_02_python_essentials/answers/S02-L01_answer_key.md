# Answer Key - S02-L01: Values, Variables, and Types

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 3

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 4

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 5

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 6

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 7

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 9

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.

## 10

**Answer:** The response should accurately use values, variables, types, store; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Python name refers to an object, and the object's type determines its valid operations. Conversion should be explicit when external input begins as text.

**Why:** The text '12.5' must be converted with float before numerical averaging; concatenating it as text would be a different operation.
