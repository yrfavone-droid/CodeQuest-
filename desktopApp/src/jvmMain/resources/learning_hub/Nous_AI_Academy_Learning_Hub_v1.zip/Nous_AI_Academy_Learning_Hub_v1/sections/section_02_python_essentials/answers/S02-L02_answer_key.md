# Answer Key - S02-L02: Conditions and Boolean Logic

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 3

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 4

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 5

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 6

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 7

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 9

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.

## 10

**Answer:** The response should accurately use conditions, boolean, logic, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean expressions combine comparisons with and, or, and not. Branch order matters when ranges overlap, so boundary values must be tested.

**Why:** For confidence >= 0.8 label high, >= 0.5 label review, otherwise low; testing 0.5 and 0.8 exposes boundary mistakes.
