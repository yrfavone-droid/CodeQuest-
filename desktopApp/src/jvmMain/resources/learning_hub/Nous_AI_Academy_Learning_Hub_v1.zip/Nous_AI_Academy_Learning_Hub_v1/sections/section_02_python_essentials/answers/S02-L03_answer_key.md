# Answer Key - S02-L03: Loops and Iteration

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 3

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 4

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 5

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 6

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 7

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 9

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.

## 10

**Answer:** The response should accurately use loops, iteration, process, sequences; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A for loop visits items from an iterable; a while loop repeats while a condition is true. Correct loops update state and have a clear termination argument.

**Why:** Summing valid scores requires separate total and count variables so skipped values do not affect the denominator.
