# Answer Key - S02-L04: Functions, Parameters, and Scope

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 3

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 4

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 5

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 6

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 7

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 9

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

## 10

**Answer:** The response should accurately use functions, parameters, scope, design; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

**Why:** A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.
