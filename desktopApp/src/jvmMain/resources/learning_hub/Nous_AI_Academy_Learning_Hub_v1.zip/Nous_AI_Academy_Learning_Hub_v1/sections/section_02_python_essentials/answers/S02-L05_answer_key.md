# Answer Key - S02-L05: Collections, Files, and Exceptions

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 3

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 4

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 5

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 6

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 7

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 9

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.

## 10

**Answer:** The response should accurately use collections, files, exceptions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

**Why:** A label counter is naturally a dictionary, while observed unique labels are naturally a set.
