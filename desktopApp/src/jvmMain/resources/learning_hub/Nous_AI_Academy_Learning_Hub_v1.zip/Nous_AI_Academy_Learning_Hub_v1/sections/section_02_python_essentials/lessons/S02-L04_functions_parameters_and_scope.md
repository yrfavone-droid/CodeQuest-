# S02-L04: Functions, Parameters, and Scope

**Academy:** Nous AI Academy  
**Section:** Python Essentials  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Design small functions with documented inputs, outputs, and error behavior.

## Key idea

A function should express one responsibility. Parameters carry inputs, return carries results, and local scope limits accidental state changes.

## Why this matters

Functions, Parameters, and Scope is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on functions, parameters, scope, design. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

A normalize function should state what happens when maximum equals minimum rather than silently dividing by zero.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Code example

```python
def minmax(x, lo, hi):
    if hi == lo: raise ValueError('zero range')
    return (x - lo) / (hi - lo)
```

## Common mistake

A common mistake is to name Functions, Parameters, and Scope without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Write, document, and test a min-max normalization function.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-02-04-001] For a local study assistant, Which statement gives the most accurate core explanation for Functions, Parameters, and Scope?
2. [foundation] [NAA-02-04-012] Apply Functions, Parameters, and Scope to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-02-04-022] Compare a correct use of Functions, Parameters, and Scope with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-02-04-032] A learner used Functions, Parameters, and Scope in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-02-04-042] Construct a boundary or edge case for Functions, Parameters, and Scope in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-02-04-052] What evidence would justify using Functions, Parameters, and Scope in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-02-04-062] Design a five-step offline activity that teaches Functions, Parameters, and Scope through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-02-04-072] Before running the code example for Functions, Parameters, and Scope, trace it line by line in the context of an offline environmental dataset. Record each important state change and identify one boundary input.
9. [challenge] [NAA-02-04-082] Evaluate this claim: 'Functions, Parameters, and Scope guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-02-04-092] Extend Functions, Parameters, and Scope from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
