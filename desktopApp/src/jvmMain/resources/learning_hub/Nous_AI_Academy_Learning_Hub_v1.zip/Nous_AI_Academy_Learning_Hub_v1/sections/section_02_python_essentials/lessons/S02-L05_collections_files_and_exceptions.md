# S02-L05: Collections, Files, and Exceptions

**Academy:** Nous AI Academy  
**Section:** Python Essentials  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Choose lists, tuples, dictionaries, and sets, then read local files defensively.

## Key idea

Lists preserve ordered mutable items, tuples represent fixed records, dictionaries map keys to values, and sets provide uniqueness. File input can fail and should be validated without hiding errors.

## Why this matters

Collections, Files, and Exceptions is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on collections, files, exceptions, choose. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

A label counter is naturally a dictionary, while observed unique labels are naturally a set.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Code example

```python
counts = {}
for label in ['A','B','A']:
    counts[label] = counts.get(label, 0) + 1
```

## Common mistake

A common mistake is to name Collections, Files, and Exceptions without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Read a local CSV-like file, collect valid records, and report malformed lines.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-02-05-001] For a local study assistant, Which statement gives the most accurate core explanation for Collections, Files, and Exceptions?
2. [foundation] [NAA-02-05-012] Apply Collections, Files, and Exceptions to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-02-05-022] Compare a correct use of Collections, Files, and Exceptions with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-02-05-032] A learner used Collections, Files, and Exceptions in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-02-05-042] Construct a boundary or edge case for Collections, Files, and Exceptions in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-02-05-052] What evidence would justify using Collections, Files, and Exceptions in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-02-05-062] Design a five-step offline activity that teaches Collections, Files, and Exceptions through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-02-05-072] Before running the code example for Collections, Files, and Exceptions, trace it line by line in the context of an offline environmental dataset. Record each important state change and identify one boundary input.
9. [challenge] [NAA-02-05-082] Evaluate this claim: 'Collections, Files, and Exceptions guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-02-05-092] Extend Collections, Files, and Exceptions from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
