# Answer Key - S03-L01: Modules, Packages, and Environments

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 3

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 4

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 5

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 6

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 7

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 9

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.

## 10

**Answer:** The response should accurately use modules, packages, environments, separate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Modules group related definitions, packages form importable namespaces, and isolated environments prevent unrelated projects from silently changing dependencies.

**Why:** A data project can separate parsing.py, features.py, model.py, and report.py while exposing only stable functions.
