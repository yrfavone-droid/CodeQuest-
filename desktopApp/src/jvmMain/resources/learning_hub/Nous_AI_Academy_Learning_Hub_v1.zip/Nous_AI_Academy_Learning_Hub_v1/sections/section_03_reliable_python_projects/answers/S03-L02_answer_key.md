# Answer Key - S03-L02: Data Classes and Object Design

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 3

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 4

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 5

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 6

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 7

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 9

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.

## 10

**Answer:** The response should accurately use classes, object, design, structured; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A data class is appropriate when named fields and validation matter. Methods should preserve class invariants, and composition is often simpler than deep inheritance.

**Why:** An Experiment record can store name, seed, parameters, and score while rejecting scores outside an allowed range.
