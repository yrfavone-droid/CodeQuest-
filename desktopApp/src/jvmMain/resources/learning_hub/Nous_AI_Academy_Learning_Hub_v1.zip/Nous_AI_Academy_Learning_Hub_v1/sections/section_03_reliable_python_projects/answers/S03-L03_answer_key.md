# Answer Key - S03-L03: Iterators and Generators

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 3

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 4

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 5

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 6

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 7

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 8

**Answer:** A complete trace names the input, follows each operation in order, predicts the result, and tests one boundary. It must be consistent with: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 9

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.

## 10

**Answer:** The response should accurately use iterators, generators, process, streams; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An iterator yields one item at a time and remembers its position. A generator creates an iterator using yield, reducing memory use but often allowing only one pass.

**Why:** A generator can read a large log line by line without placing the entire file in memory.
