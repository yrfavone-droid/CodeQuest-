# Answer Key - S03-L04: Testing and Debugging

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 3

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 4

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 5

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 6

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 7

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 9

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.

## 10

**Answer:** The response should accurately use testing, debugging, convert, assumptions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Unit tests check small contracts; integration tests check components together. A minimal failing example and a regression test are more reliable than changing many lines at once.

**Why:** Boundary tests for a probability validator should include -0.01, 0, 1, and 1.01.
