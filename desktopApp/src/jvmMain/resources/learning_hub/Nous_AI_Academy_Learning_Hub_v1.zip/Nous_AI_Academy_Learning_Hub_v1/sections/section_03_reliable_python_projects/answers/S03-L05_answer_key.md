# Answer Key - S03-L05: Complexity, Profiling, and Optimization

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 3

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 4

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 5

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 6

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 7

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 9

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.

## 10

**Answer:** The response should accurately use complexity, profiling, optimization, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Big-O notation describes growth with input size, while profiling measures actual time or memory. Replace an algorithm only after confirming the bottleneck and preserving behavior with tests.

**Why:** Checking membership in a list inside a loop can be quadratic; converting the lookup collection to a set can make expected lookups constant time.
