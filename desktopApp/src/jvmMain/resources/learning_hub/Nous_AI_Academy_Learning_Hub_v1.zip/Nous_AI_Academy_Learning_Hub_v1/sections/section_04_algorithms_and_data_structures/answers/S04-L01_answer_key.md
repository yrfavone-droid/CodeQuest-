# Answer Key - S04-L01: Arrays, Strings, Hash Maps, and Sets

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 3

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 4

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 5

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 6

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 7

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 8

**Answer:** (5, 3)

**Why:** The inner dimensions match; the outer dimensions remain.

## 9

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.

## 10

**Answer:** The response should accurately use arrays, strings, hash, maps; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Arrays and strings support direct indexing, while hash maps and sets trade memory for fast expected lookup. Correct key equality and hashing are required.

**Why:** Finding duplicates can use a set in one pass instead of repeatedly scanning the prefix.
