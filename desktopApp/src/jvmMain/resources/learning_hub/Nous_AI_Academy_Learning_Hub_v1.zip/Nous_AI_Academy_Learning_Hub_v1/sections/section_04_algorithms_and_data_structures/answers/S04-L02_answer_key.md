# Answer Key - S04-L02: Stacks, Queues, and Deques

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 3

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 4

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 5

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 6

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 7

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 9

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.

## 10

**Answer:** The response should accurately use stacks, queues, deques, access; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Stacks are last-in-first-out; queues are first-in-first-out; deques support efficient operations at both ends.

**Why:** Bracket validation uses a stack because the most recently opened bracket must close first.
