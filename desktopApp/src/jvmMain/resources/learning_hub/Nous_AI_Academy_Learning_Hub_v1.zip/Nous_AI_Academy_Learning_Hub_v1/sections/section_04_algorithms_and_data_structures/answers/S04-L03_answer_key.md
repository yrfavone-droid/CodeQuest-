# Answer Key - S04-L03: Searching, Sorting, and Recursion

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 3

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 4

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 5

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 6

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 7

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 9

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.

## 10

**Answer:** The response should accurately use searching, sorting, recursion, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

**Why:** Searching the first value >= target uses a boundary form of binary search, not only equality search.
