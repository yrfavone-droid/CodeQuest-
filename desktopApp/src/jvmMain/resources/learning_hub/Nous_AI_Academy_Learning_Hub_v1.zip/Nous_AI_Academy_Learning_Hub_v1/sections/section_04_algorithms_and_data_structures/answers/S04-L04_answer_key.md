# Answer Key - S04-L04: Trees, Heaps, and Graphs

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 3

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 4

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 5

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 6

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 7

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 9

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.

## 10

**Answer:** The response should accurately use trees, heaps, graphs, represent; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Trees model parent-child structure, heaps maintain an extreme element, and graphs model arbitrary connections. Traversal cost depends on representation.

**Why:** A priority queue can keep the next most urgent task without sorting every task after each insertion.
