# Answer Key - S04-L05: Greedy, Dynamic Programming, and Backtracking

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 3

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 4

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 5

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 6

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 7

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 9

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.

## 10

**Answer:** The response should accurately use greedy, dynamic, programming, backtracking; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Greedy algorithms commit to local choices, dynamic programming stores overlapping subproblems, and backtracking explores and reverses choices. Each requires a clear state and validity rule.

**Why:** Interval scheduling is greedy; minimum grid cost is dynamic programming; constraint scheduling may use backtracking.
