# S04-L03: Searching, Sorting, and Recursion

**Academy:** Nous AI Academy  
**Section:** Algorithms and Data Structures  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Compare linear search, binary search, merge sort, and recursive decomposition.

## Key idea

Binary search requires an ordered search space and halves it each step. Merge sort divides and combines in O(n log n); recursion needs a base case and decreasing input.

## Why this matters

Searching, Sorting, and Recursion is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on searching, sorting, recursion, compare. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

Searching the first value >= target uses a boundary form of binary search, not only equality search.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Common mistake

A common mistake is to name Searching, Sorting, and Recursion without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Implement merge sort and a lower-bound binary search with tests.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-04-03-001] For a local study assistant, Which statement gives the most accurate core explanation for Searching, Sorting, and Recursion?
2. [foundation] [NAA-04-03-012] Apply Searching, Sorting, and Recursion to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-04-03-022] Compare a correct use of Searching, Sorting, and Recursion with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-04-03-032] A learner used Searching, Sorting, and Recursion in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-04-03-042] Construct a boundary or edge case for Searching, Sorting, and Recursion in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-04-03-052] What evidence would justify using Searching, Sorting, and Recursion in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-04-03-062] Design a five-step offline activity that teaches Searching, Sorting, and Recursion through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-04-03-072] Create a minimal worked example of Searching, Sorting, and Recursion for an offline environmental dataset. Show the input, at least two intermediate steps, the output, and an independent check.
9. [challenge] [NAA-04-03-082] Evaluate this claim: 'Searching, Sorting, and Recursion guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-04-03-092] Extend Searching, Sorting, and Recursion from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
