# Answer Key - S05-L01: Arrays, Shapes, Axes, and Dtypes

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 3

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 4

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 5

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 6

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 7

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 8

**Answer:** (5, 3)

**Why:** The inner dimensions match; the outer dimensions remain.

## 9

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.

## 10

**Answer:** The response should accurately use arrays, shapes, axes, dtypes; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Shape describes axis lengths, ndim counts axes, and dtype controls representation and precision. Operations across the wrong axis can produce valid-looking but incorrect results.

**Why:** A feature matrix shaped (100, 4) has 100 examples and 4 features when rows represent examples.
