# Answer Key - S05-L02: Indexing, Masking, and Broadcasting

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 3

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 4

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 5

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 6

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 7

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 9

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.

## 10

**Answer:** The response should accurately use indexing, masking, broadcasting, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boolean masks select elements meeting a condition. Broadcasting aligns trailing dimensions when equal or one, enabling vectorized operations without copying full arrays.

**Why:** Subtracting a vector of shape (3,) from a matrix of shape (5,3) centers each column.
