# Answer Key - S05-L03: Vectorization and Performance

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 3

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 4

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 5

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 6

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 7

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 9

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.

## 10

**Answer:** The response should accurately use vectorization, performance, replace, python level; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorization delegates repeated numerical operations to optimized array routines. It improves performance but does not remove the need to verify shapes and memory use.

**Why:** A matrix-vector product X @ w replaces a loop that computes one weighted sum per row.
