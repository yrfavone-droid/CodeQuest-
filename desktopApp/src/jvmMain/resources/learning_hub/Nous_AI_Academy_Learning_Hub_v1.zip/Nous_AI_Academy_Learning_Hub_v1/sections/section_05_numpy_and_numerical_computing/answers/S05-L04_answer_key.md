# Answer Key - S05-L04: Aggregations, Randomness, and Simulation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 3

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 4

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 5

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 6

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 7

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 9

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.

## 10

**Answer:** The response should accurately use aggregations, randomness, simulation, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Aggregations reduce an axis; axis=0 summarizes rows into column results. A local random generator with a recorded seed supports reproducibility without relying on global state.

**Why:** Simulating repeated Bernoulli trials estimates an event probability and shows sampling variation.
