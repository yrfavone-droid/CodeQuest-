# Answer Key - S05-L05: Linear Algebra with NumPy

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 3

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 4

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 5

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 6

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 7

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 9

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.

## 10

**Answer:** The response should accurately use linear, algebra, numpy, matrix; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Matrix multiplication composes linear transformations. Solving Ax=b is usually more stable than computing an explicit inverse, and norms quantify vector or matrix size.

**Why:** Use np.linalg.solve for a square nonsingular system and verify with A @ x.
