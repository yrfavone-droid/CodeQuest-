# Answer Key - S06-L01: Series, DataFrames, Indexes, and Schemas

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 3

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 4

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 5

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 6

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 7

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 9

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.

## 10

**Answer:** The response should accurately use series, dataframes, indexes, schemas; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A Series is a labeled one-dimensional array; a DataFrame aligns multiple Series by index. A schema states names, types, allowed ranges, and missing-value rules.

**Why:** A learner table may require learner_id as unique text, score as float from 0 to 1, and completed as boolean.
