# Answer Key - S06-L02: Loading and Inspecting Data

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 3

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 4

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 5

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 6

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 7

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 9

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.

## 10

**Answer:** The response should accurately use loading, inspecting, read, local; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Initial inspection should check shape, columns, types, missingness, duplicates, ranges, and a few representative rows. Parsing assumptions should be explicit.

**Why:** A date column loaded as object text needs intentional parsing before time comparisons.
