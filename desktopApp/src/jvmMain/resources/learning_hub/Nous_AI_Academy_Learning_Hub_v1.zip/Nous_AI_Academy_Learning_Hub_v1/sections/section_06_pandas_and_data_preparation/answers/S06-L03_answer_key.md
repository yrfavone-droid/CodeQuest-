# Answer Key - S06-L03: Missing Values, Duplicates, and Type Repair

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 3

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 4

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 5

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 6

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 7

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 9

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.

## 10

**Answer:** The response should accurately use missing, values, duplicates, type; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Missingness may contain information and can arise for different reasons. Removing, imputing, or flagging values changes the dataset; duplicates require a documented identity definition.

**Why:** Median imputation can reduce outlier influence but still hides uncertainty if the missingness mechanism is ignored.
