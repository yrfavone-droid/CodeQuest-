# Answer Key - S06-L04: Transform, Group, and Aggregate

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 3

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 4

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 5

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 6

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 7

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 9

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.

## 10

**Answer:** The response should accurately use transform, group, aggregate, create; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Vectorized transformations operate per value or row, while groupby split-apply-combine produces summaries per group. Aggregations change granularity and must not be joined back carelessly.

**Why:** Compute mean score per course while preserving course as the result's unit.
