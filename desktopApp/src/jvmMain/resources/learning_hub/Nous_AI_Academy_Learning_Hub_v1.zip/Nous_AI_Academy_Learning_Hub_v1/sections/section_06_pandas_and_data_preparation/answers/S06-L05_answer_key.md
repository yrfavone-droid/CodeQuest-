# Answer Key - S06-L05: Merge, Reshape, and Time Data

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 3

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 4

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 5

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 6

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 7

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 9

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.

## 10

**Answer:** The response should accurately use merge, reshape, time, combine; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A join can multiply rows when keys are not unique. Merge validation, unmatched-key checks, and row-count checks prevent silent duplication.

**Why:** Joining learners to enrollments is one-to-many; joining learners to one profile row should be one-to-one.
