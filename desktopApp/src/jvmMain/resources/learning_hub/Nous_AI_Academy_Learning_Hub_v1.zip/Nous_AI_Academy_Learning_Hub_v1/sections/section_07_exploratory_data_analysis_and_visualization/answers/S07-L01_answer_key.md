# Answer Key - S07-L01: Question-First EDA

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 3

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 4

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 5

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 6

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 7

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 9

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.

## 10

**Answer:** The response should accurately use question first, connect, every, computation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: EDA is an investigation, not a gallery of charts. Start with the unit of observation, data collection process, target question, and checks that could disprove an initial belief.

**Why:** Before comparing courses, confirm whether rows represent learners, attempts, or sessions.
