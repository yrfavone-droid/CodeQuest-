# Answer Key - S07-L02: Distributions, Outliers, and Missingness

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 3

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 4

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 5

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 6

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 7

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 9

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.

## 10

**Answer:** The response should accurately use distributions, outliers, missingness, summarize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Mean and standard deviation are sensitive to extreme values; median and interquartile range are robust. An outlier may be an error or a valid rare case and should not be deleted automatically.

**Why:** A long right tail can make the mean much larger than the median.
