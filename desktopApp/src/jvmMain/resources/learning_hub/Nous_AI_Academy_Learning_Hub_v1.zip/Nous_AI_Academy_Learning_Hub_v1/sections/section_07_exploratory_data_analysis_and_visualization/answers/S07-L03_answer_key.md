# Answer Key - S07-L03: Relationships and Correlation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 3

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 4

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 5

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 6

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 7

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 9

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.

## 10

**Answer:** The response should accurately use relationships, correlation, investigate, associations; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Correlation describes a pattern of co-variation, not why it occurs. Nonlinear relationships, confounding variables, selection effects, and aggregation can mislead.

**Why:** Study time and scores may correlate because prior preparation influences both.
