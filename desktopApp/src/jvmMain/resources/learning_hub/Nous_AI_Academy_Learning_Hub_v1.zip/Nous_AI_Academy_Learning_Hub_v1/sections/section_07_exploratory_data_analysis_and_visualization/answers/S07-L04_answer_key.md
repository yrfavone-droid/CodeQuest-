# Answer Key - S07-L04: Choosing and Building Charts

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 3

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 4

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 5

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 6

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 7

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 9

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.

## 10

**Answer:** The response should accurately use choosing, building, charts, match; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Position along a common scale is usually easier to compare than area or angle. Histograms show distributions, scatterplots show two numeric variables, and bar charts compare categories.

**Why:** A line chart is appropriate for ordered time points but misleading for unordered categories.
