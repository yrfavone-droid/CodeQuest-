# Answer Key - S07-L05: Communicating Uncertainty and Limitations

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 3

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 4

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 5

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 6

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 7

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 9

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.

## 10

**Answer:** The response should accurately use communicating, uncertainty, limitations, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Good communication reports sample size, missing data, uncertainty, definitions, and plausible alternative explanations. Axes and scales must not exaggerate small changes.

**Why:** A result from one optional survey should be described as evidence from respondents, not all learners.
