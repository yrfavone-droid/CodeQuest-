# Answer Key - S08-L01: Expressions, Equations, and Inequalities

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 3

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 4

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 5

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 6

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 7

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 9

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.

## 10

**Answer:** The response should accurately use expressions, equations, inequalities, rearrange; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An equation states equality; applying the same reversible operation to both sides preserves solutions. Inequality direction reverses when multiplying or dividing by a negative number.

**Why:** From y=wx+b, isolate x as (y-b)/w when w is nonzero.
