# Answer Key - S08-L02: Functions, Graphs, and Transformations

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 3

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 4

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 5

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 6

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 7

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 9

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.

## 10

**Answer:** The response should accurately use functions, graphs, transformations, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A function maps each allowed input to one output. Transformations such as f(x-a), cf(x), and f(cx) shift or scale the graph in predictable ways.

**Why:** Adding a positive bias shifts a linear score upward without changing its slope.
