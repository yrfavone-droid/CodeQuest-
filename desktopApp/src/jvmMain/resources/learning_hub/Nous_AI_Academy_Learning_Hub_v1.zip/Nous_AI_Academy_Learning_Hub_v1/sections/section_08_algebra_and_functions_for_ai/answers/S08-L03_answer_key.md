# Answer Key - S08-L03: Exponents and Logarithms

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 3

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 4

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 5

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 6

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 7

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 9

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.

## 10

**Answer:** The response should accurately use exponents, logarithms, growth, laws; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Exponents turn repeated multiplication into notation; logarithms answer which exponent produces a value. log(ab)=log(a)+log(b) helps convert products into sums.

**Why:** Taking logs of a product of small probabilities can prevent underflow and simplify comparison.
