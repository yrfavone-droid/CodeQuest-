# Answer Key - S08-L04: Sequences, Summation, and Averages

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 3

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 4

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 5

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 6

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 7

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 9

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.

## 10

**Answer:** The response should accurately use sequences, summation, averages, read; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Sigma notation specifies an index, limits, and an expression to add. A weighted mean divides the weighted sum by total weight.

**Why:** Mean squared error is (1/n) times the sum of squared residuals.
