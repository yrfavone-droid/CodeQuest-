# Answer Key - S08-L05: Objectives and Loss Functions

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 3

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 4

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 5

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 6

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 7

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 8

**Answer:** 6.5

**Why:** MSE = (3^2 + 2^2) / 2 = 6.5.

## 9

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.

## 10

**Answer:** The response should accurately use objectives, loss, functions, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A loss assigns a numerical penalty to a prediction. Squared loss magnifies large residuals; absolute loss grows linearly; cross-entropy evaluates predicted class probabilities.

**Why:** Predicting 0.9 for the wrong class receives a larger cross-entropy penalty than predicting 0.55.
