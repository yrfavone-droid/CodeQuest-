# Answer Key - S09-L01: Vectors, Norms, and Dot Products

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 3

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 4

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 5

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 6

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 7

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 8

**Answer:** 14

**Why:** Multiply matching entries and add: 3*2 + 2*4 = 14.

## 9

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.

## 10

**Answer:** The response should accurately use vectors, norms, products, features; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A vector is an ordered list with geometric and algebraic meaning. The dot product sums pairwise products and equals the product of norms times cosine similarity.

**Why:** A model score w dot x is a weighted combination of features.
