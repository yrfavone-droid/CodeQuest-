# Answer Key - S09-L02: Matrices and Matrix Multiplication

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 3

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 4

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 5

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 6

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 7

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 8

**Answer:** (5, 3)

**Why:** The inner dimensions match; the outer dimensions remain.

## 9

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).

## 10

**Answer:** The response should accurately use matrices, matrix, multiplication, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An m by n matrix maps n-dimensional vectors to m-dimensional vectors. AB is defined when inner dimensions match, and generally AB is not BA.

**Why:** A batch X with shape (32,5) multiplied by weights (5,2) produces predictions (32,2).
