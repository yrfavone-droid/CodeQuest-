# Answer Key - S09-L03: Linear Systems, Rank, and Inverses

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 3

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 4

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 5

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 6

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 7

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 9

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.

## 10

**Answer:** The response should accurately use linear, systems, rank, inverses; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Rank measures independent directions. A square full-rank matrix has a unique solution for every b, but numerical work should solve systems directly rather than explicitly forming an inverse.

**Why:** Nearly dependent columns can make a fitted solution unstable even when a numerical answer exists.
