# Answer Key - S09-L04: Linear Transformations, Basis, and Projections

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 3

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 4

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 5

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 6

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 7

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 9

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.

## 10

**Answer:** The response should accurately use linear, transformations, basis, projections; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A basis provides coordinate directions. Projection finds the component of a vector within a subspace and is central to least squares.

**Why:** Projecting a point onto the span of a feature vector gives the closest one-dimensional approximation.
