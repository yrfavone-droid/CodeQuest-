# Answer Key - S09-L05: Eigenvectors, SVD, and PCA

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 3

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 4

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 5

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 6

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 7

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 8

**Answer:** 14

**Why:** Multiply matching entries and add: 3*2 + 2*4 = 14.

## 9

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

## 10

**Answer:** The response should accurately use eigenvectors, connect, stable, directions; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

**Why:** Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.
