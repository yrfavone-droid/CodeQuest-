# S09-L05: Eigenvectors, SVD, and PCA

**Academy:** Nous AI Academy  
**Section:** Linear Algebra for Machine Learning  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Connect stable directions and singular components to dimensionality reduction.

## Key idea

Eigenvectors preserve direction under a square transformation. SVD factors any matrix into orthogonal directions and singular values; PCA uses leading variance directions after centering data.

## Why this matters

Eigenvectors, SVD, and PCA is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on eigenvectors, connect, stable, directions. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

Keeping the first two principal components compresses data while preserving as much sample variance as those components capture.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Common mistake

A common mistake is to name Eigenvectors, SVD, and PCA without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Run PCA with NumPy, reconstruct data, and measure information loss.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-09-05-001] For a local study assistant, Which statement gives the most accurate core explanation for Eigenvectors, SVD, and PCA?
2. [foundation] [NAA-09-05-012] Apply Eigenvectors, SVD, and PCA to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-09-05-022] Compare a correct use of Eigenvectors, SVD, and PCA with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-09-05-032] A learner used Eigenvectors, SVD, and PCA in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-09-05-042] Construct a boundary or edge case for Eigenvectors, SVD, and PCA in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-09-05-052] What evidence would justify using Eigenvectors, SVD, and PCA in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-09-05-062] Design a five-step offline activity that teaches Eigenvectors, SVD, and PCA through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-09-05-072] Compute the dot product of [3, 2] and [2, 4].
9. [challenge] [NAA-09-05-082] Evaluate this claim: 'Eigenvectors, SVD, and PCA guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-09-05-092] Extend Eigenvectors, SVD, and PCA from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
