# Answer Key - S10-L01: Probability Rules and Conditional Probability

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 3

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 4

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 5

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 6

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 7

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 8

**Answer:** 0.2727272727272727

**Why:** P(A|B) = count(A and B)/count(B) = 6/22 = 0.272727.

## 9

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.

## 10

**Answer:** The response should accurately use probability, rules, conditional, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Conditional probability P(A|B)=P(A and B)/P(B) changes the reference population to cases where B occurred. Independence means conditioning does not change the probability.

**Why:** The accuracy among positive predictions is not the same as overall accuracy because the denominator is different.
