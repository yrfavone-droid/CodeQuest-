# Answer Key - S10-L02: Bayes' Rule

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 3

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 4

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 5

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 6

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 7

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 8

**Answer:** 0.2727272727272727

**Why:** P(A|B) = count(A and B)/count(B) = 6/22 = 0.272727.

## 9

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.

## 10

**Answer:** The response should accurately use bayes, rule, update, prior; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bayes' rule combines a prior with how compatible evidence is under competing hypotheses. Rare base rates can dominate even when a test appears accurate.

**Why:** A detector with high sensitivity can still produce many false positives when the event is extremely rare.
