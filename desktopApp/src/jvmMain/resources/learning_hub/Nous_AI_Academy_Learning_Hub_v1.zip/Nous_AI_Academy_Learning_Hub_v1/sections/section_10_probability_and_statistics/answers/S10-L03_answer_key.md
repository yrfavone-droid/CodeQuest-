# Answer Key - S10-L03: Random Variables and Distributions

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 3

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 4

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 5

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 6

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 7

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 9

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.

## 10

**Answer:** The response should accurately use random, variables, distributions, choose; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A random variable maps outcomes to numbers, and a distribution assigns probabilities or densities. Distribution choice is a model, not a fact guaranteed by the variable's appearance.

**Why:** A single yes/no result is Bernoulli; the count of successes in fixed independent trials is binomial.
