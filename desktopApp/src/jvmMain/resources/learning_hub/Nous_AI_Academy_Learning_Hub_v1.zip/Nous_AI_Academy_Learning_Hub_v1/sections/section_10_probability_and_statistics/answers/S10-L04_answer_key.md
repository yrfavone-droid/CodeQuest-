# Answer Key - S10-L04: Expectation, Variance, and Sampling

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 3

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 4

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 5

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 6

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 7

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 9

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.

## 10

**Answer:** The response should accurately use expectation, variance, sampling, calculate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Expectation is a probability-weighted long-run average; variance measures squared deviation from the mean. Sample estimates vary across samples, and larger independent samples usually reduce standard error.

**Why:** A fair die has expected value 3.5 even though 3.5 is not a possible roll.
