# Answer Key - S10-L05: Intervals, Tests, and Causal Caution

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 3

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 4

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 5

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 6

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 7

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 9

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.

## 10

**Answer:** The response should accurately use intervals, tests, causal, caution; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confidence interval procedure has long-run coverage under its assumptions. A p-value measures compatibility with a null model, not the probability that the null is true; association alone does not establish causation.

**Why:** A narrow interval from biased sampling can be precisely wrong.
