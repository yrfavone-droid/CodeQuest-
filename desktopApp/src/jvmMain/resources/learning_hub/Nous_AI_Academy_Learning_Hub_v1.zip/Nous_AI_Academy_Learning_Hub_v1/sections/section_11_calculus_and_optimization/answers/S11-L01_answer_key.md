# Answer Key - S11-L01: Rates of Change and Derivatives

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 3

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 4

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 5

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 6

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 7

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 9

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.

## 10

**Answer:** The response should accurately use rates, change, derivatives, interpret; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The derivative is the limit of a difference quotient when that limit exists. Its sign indicates local increase or decrease, and its magnitude measures sensitivity to small input changes.

**Why:** For f(x)=x squared, f'(x)=2x, so the same input change has a larger effect at larger |x|.
