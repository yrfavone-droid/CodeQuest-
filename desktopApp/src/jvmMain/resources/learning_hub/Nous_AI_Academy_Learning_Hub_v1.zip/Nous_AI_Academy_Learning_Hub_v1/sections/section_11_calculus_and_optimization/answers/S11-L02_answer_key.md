# Answer Key - S11-L02: Partial Derivatives and Gradients

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 3

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 4

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 5

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 6

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 7

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 9

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.

## 10

**Answer:** The response should accurately use partial, derivatives, gradients, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A partial derivative changes one variable at a time. The gradient collects all partial derivatives and points in the direction of steepest local increase.

**Why:** For L(w,b)=(wx+b-y)^2, compute separate derivatives with respect to w and b.
