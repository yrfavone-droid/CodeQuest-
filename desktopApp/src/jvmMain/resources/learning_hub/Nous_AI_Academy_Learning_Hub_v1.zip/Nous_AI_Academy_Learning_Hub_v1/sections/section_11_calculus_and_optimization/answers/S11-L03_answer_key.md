# Answer Key - S11-L03: Chain Rule and Computation Graphs

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 3

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 4

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 5

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 6

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 7

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 9

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.

## 10

**Answer:** The response should accurately use chain, rule, computation, graphs; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: If an output depends on an intermediate value, the chain rule multiplies local derivatives along each path and sums contributions from multiple paths.

**Why:** For z=wx+b, p=sigmoid(z), and loss(p), backpropagation moves from loss to p to z to w and b.
