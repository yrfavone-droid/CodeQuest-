# Answer Key - S11-L04: Gradient Descent and Learning Rates

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 3

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 4

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 5

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 6

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 7

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 8

**Answer:** 2.8

**Why:** theta_new = 3 - 0.1*2 = 2.8.

## 9

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.

## 10

**Answer:** The response should accurately use gradient, descent, learning, rates; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Gradient descent updates theta := theta - eta times gradient. A small rate may converge slowly; a large rate may overshoot or diverge; feature scale affects both.

**Why:** Minimize a quadratic from two starting points and compare three learning rates.
