# Answer Key - S11-L05: Regularization and Numerical Stability

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 3

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 4

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 5

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 6

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 7

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 9

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.

## 10

**Answer:** The response should accurately use regularization, numerical, stability, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization adds a preference such as small weights to the objective. Numerical stability uses equivalent formulations, scaling, clipping where justified, and log-sum-exp to avoid overflow or underflow.

**Why:** Computing log(sum(exp(z))) should subtract max(z) before exponentiating.
