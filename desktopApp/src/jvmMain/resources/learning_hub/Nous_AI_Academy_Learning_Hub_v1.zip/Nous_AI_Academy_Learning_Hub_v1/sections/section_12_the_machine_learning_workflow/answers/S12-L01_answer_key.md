# Answer Key - S12-L01: Problem Framing and Baselines

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 3

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 4

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 5

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 6

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 7

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 9

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.

## 10

**Answer:** The response should accurately use problem, framing, baselines, translate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A model objective must connect to a real use decision. A baseline such as majority class, mean prediction, or simple rule shows whether complexity adds value.

**Why:** A dropout-risk model must define prediction time so post-outcome information cannot enter features.
