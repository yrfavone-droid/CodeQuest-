# Answer Key - S12-L02: Train, Validation, Test, and Leakage

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 3

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 4

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 5

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 6

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 7

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 9

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.

## 10

**Answer:** The response should accurately use train, validation, test, leakage; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Training fits parameters, validation selects models or thresholds, and test data estimates final performance after choices stop. Related examples must stay in the same split when independence would otherwise be false.

**Why:** Randomly splitting repeated records from the same learner leaks identity patterns across splits.
