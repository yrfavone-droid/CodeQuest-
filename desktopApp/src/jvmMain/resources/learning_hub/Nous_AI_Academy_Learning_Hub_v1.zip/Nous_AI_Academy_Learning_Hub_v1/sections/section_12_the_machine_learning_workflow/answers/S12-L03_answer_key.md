# Answer Key - S12-L03: Preprocessing and Pipelines

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 3

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 4

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 5

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 6

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 7

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 9

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.

## 10

**Answer:** The response should accurately use preprocessing, pipelines, transformations, only; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaling, imputation, encoding, and feature selection learn statistics. A pipeline prevents validation or test information from influencing those statistics.

**Why:** Using the entire dataset mean to impute before splitting leaks information from held-out rows.
