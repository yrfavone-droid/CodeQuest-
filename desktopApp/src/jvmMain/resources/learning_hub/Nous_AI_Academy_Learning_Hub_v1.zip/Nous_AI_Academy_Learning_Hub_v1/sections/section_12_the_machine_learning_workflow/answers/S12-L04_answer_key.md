# Answer Key - S12-L04: Metrics and Thresholds

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 3

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 4

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 5

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 6

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 7

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 9

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.

## 10

**Answer:** The response should accurately use metrics, thresholds, select, error; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Accuracy can hide minority-class failure. Precision asks how many predicted positives were correct; recall asks how many actual positives were found; thresholds trade these errors.

**Why:** For a screening support tool, missed cases and false alarms may have different consequences.
