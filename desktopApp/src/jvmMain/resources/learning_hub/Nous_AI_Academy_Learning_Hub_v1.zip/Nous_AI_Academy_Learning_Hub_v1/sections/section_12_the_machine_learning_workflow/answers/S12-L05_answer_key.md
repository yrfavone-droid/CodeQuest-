# Answer Key - S12-L05: Cross-Validation, Tuning, and Reproducibility

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 3

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 4

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 5

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 6

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 7

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 9

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.

## 10

**Answer:** The response should accurately use cross validation, tuning, reproducibility, estimate; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Cross-validation repeats training across folds to estimate stability. Hyperparameters are chosen using training/validation evidence, while the final test set remains untouched.

**Why:** Reporting only the best fold is selection bias; report the distribution or mean and spread.
