# Answer Key - S13-L01: Simple and Multiple Linear Regression

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 3

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 4

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 5

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 6

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 7

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 9

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.

## 10

**Answer:** The response should accurately use simple, multiple, linear, regression; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression predicts a weighted sum. A coefficient is the model's change in prediction for a one-unit feature change while other included features are held fixed; it is not automatically causal.

**Why:** A study-hour coefficient of 2 predicts two more score points per hour under the fitted model and feature definitions.
