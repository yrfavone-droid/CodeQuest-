# Answer Key - S13-L02: Mean Squared Error and Fitting

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 3

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 4

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 5

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 6

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 7

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 8

**Answer:** 6.5

**Why:** MSE = (3^2 + 2^2) / 2 = 6.5.

## 9

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.

## 10

**Answer:** The response should accurately use mean, squared, error, fitting; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A residual is observed minus predicted. MSE averages squared residuals, penalizing large errors strongly; least squares chooses parameters minimizing the sum of squared residuals.

**Why:** Two residuals of 1 and 3 produce MSE 5 because (1+9)/2=5.
