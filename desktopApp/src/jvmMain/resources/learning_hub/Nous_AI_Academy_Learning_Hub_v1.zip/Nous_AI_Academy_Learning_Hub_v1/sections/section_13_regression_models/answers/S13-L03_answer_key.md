# Answer Key - S13-L03: Assumptions and Residual Diagnostics

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 3

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 4

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 5

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 6

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 7

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 9

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.

## 10

**Answer:** The response should accurately use assumptions, residual, diagnostics, plots; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Linear regression inference often assumes a suitable linear mean, independent errors, stable variance, and well-behaved residuals. Prediction can still be useful while some inference assumptions fail, but limitations must be stated.

**Why:** A funnel-shaped residual plot suggests error variance grows with fitted value.
