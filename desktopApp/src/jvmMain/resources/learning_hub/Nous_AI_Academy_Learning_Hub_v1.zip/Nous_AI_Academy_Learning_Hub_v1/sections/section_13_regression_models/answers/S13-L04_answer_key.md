# Answer Key - S13-L04: Ridge and Lasso Regularization

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 3

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 4

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 5

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 6

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 7

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 9

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.

## 10

**Answer:** The response should accurately use ridge, lasso, regularization, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Ridge adds squared coefficient magnitude and shrinks correlated weights smoothly. Lasso adds absolute magnitude and can set some coefficients exactly to zero.

**Why:** Standardization matters because penalties otherwise depend on feature units.
