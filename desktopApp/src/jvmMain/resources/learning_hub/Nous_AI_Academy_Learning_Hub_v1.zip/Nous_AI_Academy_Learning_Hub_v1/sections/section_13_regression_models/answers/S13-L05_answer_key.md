# Answer Key - S13-L05: Nonlinear and Tree Regression

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 3

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 4

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 5

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 6

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 7

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 9

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.

## 10

**Answer:** The response should accurately use nonlinear, tree, regression, recognize; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Polynomial features keep a linear model in parameters while allowing curved input relationships. Regression trees partition feature space into regions with constant predictions.

**Why:** A tree can model threshold effects but may be unstable and overfit without depth or leaf controls.
