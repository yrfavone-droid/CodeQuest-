# Answer Key - S14-L01: Logistic Regression and the Sigmoid

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 3

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 4

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 5

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 6

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 7

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 8

**Answer:** 0.1824

**Why:** 1/(1+exp(--1.5)) = 0.1824.

## 9

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.

## 10

**Answer:** The response should accurately use logistic, regression, sigmoid, convert; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Logistic regression applies sigmoid(z)=1/(1+exp(-z)) to a linear score. The log-odds are linear in the features, while the output lies between zero and one.

**Why:** A score z=0 maps to probability 0.5; positive scores map above 0.5.
