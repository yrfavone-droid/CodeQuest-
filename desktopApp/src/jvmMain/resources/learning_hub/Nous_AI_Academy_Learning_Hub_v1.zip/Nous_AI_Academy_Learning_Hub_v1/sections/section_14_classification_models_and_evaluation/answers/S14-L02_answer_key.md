# Answer Key - S14-L02: Confusion Matrices and Thresholds

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 3

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 4

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 5

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 6

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 7

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 8

**Answer:** 0.7857142857142857

**Why:** Precision = TP/(TP+FP) = 11/14 = 0.785714.

## 9

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

## 10

**Answer:** The response should accurately use confusion, matrices, thresholds, derive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

**Why:** Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.
