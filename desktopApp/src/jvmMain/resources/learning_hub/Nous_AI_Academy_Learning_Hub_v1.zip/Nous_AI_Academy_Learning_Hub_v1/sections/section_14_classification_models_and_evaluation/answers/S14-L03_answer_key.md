# Answer Key - S14-L03: Precision, Recall, F1, ROC, and PR

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 3

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 4

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 5

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 6

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 7

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 8

**Answer:** 0.7857142857142857

**Why:** Precision = TP/(TP+FP) = 11/14 = 0.785714.

## 9

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.

## 10

**Answer:** The response should accurately use precision, recall, choose, evaluation; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Precision=TP/(TP+FP), recall=TP/(TP+FN), and F1 is their harmonic mean. ROC and precision-recall curves summarize thresholds, but PR is often more informative for rare positive classes.

**Why:** A high ROC-AUC can coexist with poor precision when prevalence is very low.
