# Answer Key - S14-L04: k-NN, Naive Bayes, and SVM

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 3

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 4

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 5

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 6

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 7

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 8

**Answer:** 0.2727272727272727

**Why:** P(A|B) = count(A and B)/count(B) = 6/22 = 0.272727.

## 9

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.

## 10

**Answer:** The response should accurately use k nn, naive, bayes, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-NN predicts from nearby examples and needs scaling; Naive Bayes combines feature likelihoods under conditional independence; SVM seeks a wide separating margin and can use kernels.

**Why:** Text word counts often suit naive Bayes as a strong baseline despite imperfect independence.
