# Answer Key - S14-L05: Calibration, Imbalance, and Error Analysis

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 3

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 4

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 5

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 6

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 7

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 8

**Answer:** 0.7857142857142857

**Why:** Precision = TP/(TP+FP) = 11/14 = 0.785714.

## 9

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.

## 10

**Answer:** The response should accurately use calibration, imbalance, error, analysis; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A calibrated 0.7 prediction should be correct about 70% of the time among similar predictions. Class weights, resampling, and thresholding address different aspects of imbalance and must be validated.

**Why:** Oversampling before splitting duplicates information into validation and causes leakage.
