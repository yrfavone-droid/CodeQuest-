# S14-L02: Confusion Matrices and Thresholds

**Academy:** Nous AI Academy  
**Section:** Classification Models and Evaluation  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Derive classification counts and change behavior through thresholds.

## Key idea

A confusion matrix counts true positives, false positives, true negatives, and false negatives. The threshold turns a score into a class and should reflect error costs, not habit.

## Why this matters

Confusion Matrices and Thresholds is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on confusion, matrices, thresholds, derive. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

Raising a positive threshold usually decreases predicted positives, often increasing precision and reducing recall.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Common mistake

A common mistake is to name Confusion Matrices and Thresholds without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Calculate matrices at three thresholds.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-14-02-001] For a local study assistant, Which statement gives the most accurate core explanation for Confusion Matrices and Thresholds?
2. [foundation] [NAA-14-02-012] Apply Confusion Matrices and Thresholds to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-14-02-022] Compare a correct use of Confusion Matrices and Thresholds with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-14-02-032] A learner used Confusion Matrices and Thresholds in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-14-02-042] Construct a boundary or edge case for Confusion Matrices and Thresholds in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-14-02-052] What evidence would justify using Confusion Matrices and Thresholds in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-14-02-062] Design a five-step offline activity that teaches Confusion Matrices and Thresholds through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-14-02-072] A classifier has TP=11 and FP=3. Compute precision.
9. [challenge] [NAA-14-02-082] Evaluate this claim: 'Confusion Matrices and Thresholds guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-14-02-092] Extend Confusion Matrices and Thresholds from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
