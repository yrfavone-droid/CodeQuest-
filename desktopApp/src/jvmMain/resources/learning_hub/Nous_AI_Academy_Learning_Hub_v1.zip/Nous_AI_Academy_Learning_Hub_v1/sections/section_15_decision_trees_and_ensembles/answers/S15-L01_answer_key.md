# Answer Key - S15-L01: Decision Tree Splits

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 3

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 4

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 5

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 6

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 7

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 9

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.

## 10

**Answer:** The response should accurately use decision, tree, splits, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A decision tree recursively partitions data. Classification splits seek purer child nodes using measures such as Gini impurity or entropy; regression splits reduce squared error.

**Why:** A split on score < 0.6 separates rows into two groups and is useful only if child targets become more homogeneous.
