# Answer Key - S15-L02: Overfitting, Depth, and Pruning

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 3

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 4

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 5

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 6

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 7

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 9

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.

## 10

**Answer:** The response should accurately use overfitting, depth, pruning, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deep trees can memorize small regions and noise. Maximum depth, minimum leaf size, and pruning reduce variance while potentially increasing bias.

**Why:** A leaf containing one training example can be perfectly pure but unreliable for new data.
