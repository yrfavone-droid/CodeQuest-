# Answer Key - S15-L03: Bagging and Random Forests

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 3

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 4

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 5

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 6

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 7

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 9

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.

## 10

**Answer:** The response should accurately use bagging, random, forests, explain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bagging fits models on bootstrap samples and averages them. Random forests also sample candidate features at splits, reducing correlation between trees so averaging works better.

**Why:** Many diverse high-variance trees can form a stable predictor when their errors are not identical.
