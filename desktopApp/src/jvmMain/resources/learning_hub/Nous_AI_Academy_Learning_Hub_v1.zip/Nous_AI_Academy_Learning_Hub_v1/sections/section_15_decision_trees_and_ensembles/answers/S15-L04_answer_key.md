# Answer Key - S15-L04: Gradient Boosting

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 3

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 4

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 5

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 6

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 7

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 9

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.

## 10

**Answer:** The response should accurately use gradient, boosting, describe, sequential; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Boosting adds weak learners sequentially, each targeting the current errors or loss gradient. Learning rate and number of learners control the fit-complexity tradeoff.

**Why:** For squared loss, a new regression tree can fit current residuals and add a scaled correction.
