# Answer Key - S15-L05: Feature Importance and Interpretation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 3

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 4

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 5

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 6

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 7

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 9

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.

## 10

**Answer:** The response should accurately use feature, importance, interpretation, global; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Impurity importance can favor high-cardinality features; permutation importance measures performance change after shuffling; local explanations describe one prediction. Correlated features can share or hide importance.

**Why:** If two features duplicate one another, shuffling one may appear unimportant because the other remains.
