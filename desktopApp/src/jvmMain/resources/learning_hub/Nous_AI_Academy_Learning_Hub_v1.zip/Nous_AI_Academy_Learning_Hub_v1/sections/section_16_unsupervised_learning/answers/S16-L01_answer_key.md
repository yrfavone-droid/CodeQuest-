# Answer Key - S16-L01: k-Means Clustering

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 3

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 4

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 5

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 6

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 7

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 9

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.

## 10

**Answer:** The response should accurately use k means, clustering, apply, assignment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: k-means minimizes within-cluster squared Euclidean distance. It works best for roughly compact, similarly scaled groups and is sensitive to initialization and outliers.

**Why:** Unscaled income can dominate age because Euclidean distance depends on units.
