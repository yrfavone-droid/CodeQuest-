# Answer Key - S16-L02: Hierarchical Clustering and DBSCAN

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 3

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 4

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 5

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 6

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 7

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 9

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.

## 10

**Answer:** The response should accurately use hierarchical, clustering, dbscan, compare; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

**Why:** DBSCAN can identify curved clusters that k-means cannot represent well.
