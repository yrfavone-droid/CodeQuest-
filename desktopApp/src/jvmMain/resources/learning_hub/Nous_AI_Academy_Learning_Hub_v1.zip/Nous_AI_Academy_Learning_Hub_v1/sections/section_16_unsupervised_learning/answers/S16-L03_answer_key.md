# Answer Key - S16-L03: PCA for Dimensionality Reduction

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 3

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 4

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 5

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 6

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 7

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 9

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.

## 10

**Answer:** The response should accurately use dimensionality, reduction, center, project; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: PCA finds orthogonal directions with decreasing sample variance. It is scale-sensitive and captures linear structure; components are combinations of original features.

**Why:** Standardization can be required when features use unrelated units.
