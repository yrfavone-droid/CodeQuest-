# Answer Key - S16-L04: Anomaly Detection

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 3

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 4

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 5

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 6

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 7

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 9

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.

## 10

**Answer:** The response should accurately use anomaly, detection, define, anomalies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An anomaly is unusual under a reference pattern, not automatically wrong or harmful. Isolation forests, distance methods, and statistical rules encode different notions of unusualness.

**Why:** A high value may be normal for one subgroup and anomalous for another.
