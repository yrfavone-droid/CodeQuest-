# Answer Key - S16-L05: Evaluating Unlabeled Structure

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 3

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 4

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 5

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 6

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 7

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 9

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.

## 10

**Answer:** The response should accurately use evaluating, unlabeled, structure, stability; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Silhouette score compares within-cluster cohesion with nearest-cluster separation, but a high score does not guarantee meaningful groups. Results should be stable across seeds and useful for a stated purpose.

**Why:** A mathematically distinct cluster may simply encode a data collection artifact.
