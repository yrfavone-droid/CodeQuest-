# S16-L02: Hierarchical Clustering and DBSCAN

**Academy:** Nous AI Academy  
**Section:** Unsupervised Learning  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Compare linkage trees with density-based clusters.

## Key idea

Hierarchical clustering builds a dendrogram using a linkage rule. DBSCAN groups dense regions and marks sparse points as noise, without requiring a cluster count but depending on distance scale and neighborhood parameters.

## Why this matters

Hierarchical Clustering and DBSCAN is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on hierarchical, clustering, dbscan, compare. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

DBSCAN can identify curved clusters that k-means cannot represent well.

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Common mistake

A common mistake is to name Hierarchical Clustering and DBSCAN without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Cluster two synthetic shapes and compare methods.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-16-02-001] For a local study assistant, Which statement gives the most accurate core explanation for Hierarchical Clustering and DBSCAN?
2. [foundation] [NAA-16-02-012] Apply Hierarchical Clustering and DBSCAN to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-16-02-022] Compare a correct use of Hierarchical Clustering and DBSCAN with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-16-02-032] A learner used Hierarchical Clustering and DBSCAN in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-16-02-042] Construct a boundary or edge case for Hierarchical Clustering and DBSCAN in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-16-02-052] What evidence would justify using Hierarchical Clustering and DBSCAN in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-16-02-062] Design a five-step offline activity that teaches Hierarchical Clustering and DBSCAN through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-16-02-072] Create a minimal worked example of Hierarchical Clustering and DBSCAN for an offline environmental dataset. Show the input, at least two intermediate steps, the output, and an independent check.
9. [challenge] [NAA-16-02-082] Evaluate this claim: 'Hierarchical Clustering and DBSCAN guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-16-02-092] Extend Hierarchical Clustering and DBSCAN from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
