# Answer Key - S17-L01: Perceptrons, Layers, and Shapes

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 3

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 4

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 5

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 6

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 7

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 8

**Answer:** (5, 3)

**Why:** The inner dimensions match; the outer dimensions remain.

## 9

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

## 10

**Answer:** The response should accurately use perceptrons, layers, shapes, compute; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

**Why:** Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).
