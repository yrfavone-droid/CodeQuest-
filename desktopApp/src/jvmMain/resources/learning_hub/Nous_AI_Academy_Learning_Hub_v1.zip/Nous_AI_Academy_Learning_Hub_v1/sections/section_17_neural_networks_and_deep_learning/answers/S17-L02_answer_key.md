# Answer Key - S17-L02: Activation and Loss Functions

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 3

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 4

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 5

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 6

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 7

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 8

**Answer:** 6.5

**Why:** MSE = (3^2 + 2^2) / 2 = 6.5.

## 9

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.

## 10

**Answer:** The response should accurately use activation, loss, functions, select; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: ReLU provides piecewise-linear hidden activations; sigmoid and softmax map outputs for binary and multiclass tasks. Cross-entropy matches probabilistic classification better than arbitrary squared error.

**Why:** Softmax outputs sum to one across classes but can still be overconfident.
