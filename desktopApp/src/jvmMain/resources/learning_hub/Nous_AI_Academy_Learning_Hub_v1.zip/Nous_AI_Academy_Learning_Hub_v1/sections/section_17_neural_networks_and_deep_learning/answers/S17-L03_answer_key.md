# Answer Key - S17-L03: Forward Pass and Backpropagation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 3

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 4

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 5

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 6

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 7

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 9

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.

## 10

**Answer:** The response should accurately use forward, pass, backpropagation, chain; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: The forward pass stores intermediate values; backpropagation reuses them to apply local derivatives from loss toward earlier parameters. Gradient shape must match parameter shape.

**Why:** For a dense layer, dW = X transpose times dZ and db sums dZ across the batch.
