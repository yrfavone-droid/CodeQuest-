# Answer Key - S17-L04: Optimization and Training Loops

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 3

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 4

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 5

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 6

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 7

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 9

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.

## 10

**Answer:** The response should accurately use optimization, training, loops, write; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A training loop selects batches, computes predictions and loss, zeroes old gradients, backpropagates, updates parameters, and evaluates separately. Adam adapts updates but does not remove the need for a sensible learning rate.

**Why:** Validation loss rising while training loss falls indicates increasing overfit.
