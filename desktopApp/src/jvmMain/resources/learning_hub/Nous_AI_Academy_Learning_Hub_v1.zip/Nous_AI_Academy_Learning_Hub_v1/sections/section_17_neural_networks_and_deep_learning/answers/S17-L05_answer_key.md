# Answer Key - S17-L05: Regularization and Reliable Evaluation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 3

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 4

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 5

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 6

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 7

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 9

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.

## 10

**Answer:** The response should accurately use regularization, reliable, evaluation, weight; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Regularization aims to improve generalization, not only reduce training loss. Dropout is active during training and disabled at evaluation; early stopping choices use validation data, never the test set.

**Why:** An ablation removes one component while holding other settings constant to measure its contribution.
