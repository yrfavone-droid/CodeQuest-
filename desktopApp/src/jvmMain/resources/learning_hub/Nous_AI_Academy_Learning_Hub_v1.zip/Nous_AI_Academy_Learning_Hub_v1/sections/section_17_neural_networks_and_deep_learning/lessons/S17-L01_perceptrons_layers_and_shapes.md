# S17-L01: Perceptrons, Layers, and Shapes

**Academy:** Nous AI Academy  
**Section:** Neural Networks and Deep Learning  
**Estimated study time:** 45-60 minutes  
**Offline:** Yes

## Learning objective

Compute a neuron and trace tensor shapes through dense layers.

## Key idea

A neuron computes an affine transformation followed by an activation. Dense layers apply many neurons to a batch, so weight shapes must align input and output dimensions.

## Why this matters

Perceptrons, Layers, and Shapes is useful only when the learner can connect the idea to a concrete decision or computation. In this lesson, focus on perceptrons, layers, shapes, compute. State what enters the process, what operation occurs, what leaves the process, and what observation would show that the result is wrong.

A strong explanation moves between plain language, symbols or code when appropriate, and a checked example. It also separates what the method guarantees from what depends on assumptions, data quality, and evaluation design.

## Worked example

Input (32,10) times weights (10,20) plus bias (20,) produces activation (32,20).

Use this six-step reasoning pattern:

1. Restate the task and identify the unit being analyzed.
2. List known inputs, required output, and constraints.
3. Predict the result or behavior before computing.
4. Apply the smallest correct method one step at a time.
5. Verify with a boundary case, invariant, baseline, or second calculation.
6. State one assumption and one limitation.

## Common mistake

A common mistake is to name Perceptrons, Layers, and Shapes without applying its mechanism or checking whether its assumptions fit the task. Another is to report one successful output as proof that the method will generalize. Preserve a failing example and add a check before changing the implementation.

## Guided lab

Implement a dense forward pass with NumPy.

Save four artifacts locally: the input, expected result, observed result, and a short explanation of any difference.

## Lesson practice

1. [foundation] [NAA-17-01-001] For a local study assistant, Which statement gives the most accurate core explanation for Perceptrons, Layers, and Shapes?
2. [foundation] [NAA-17-01-012] Apply Perceptrons, Layers, and Shapes to an offline environmental dataset. State the input, method, expected output, and one check that could reveal an error.
3. [foundation] [NAA-17-01-022] Compare a correct use of Perceptrons, Layers, and Shapes with a tempting but incorrect shortcut in an offline environmental dataset. Explain the practical consequence.
4. [foundation] [NAA-17-01-032] A learner used Perceptrons, Layers, and Shapes in an offline environmental dataset and obtained a plausible result without validating assumptions. Diagnose the likely weakness and propose a smallest useful test.
5. [practice] [NAA-17-01-042] Construct a boundary or edge case for Perceptrons, Layers, and Shapes in an offline environmental dataset. Predict the correct behavior and explain why a naive method might fail.
6. [practice] [NAA-17-01-052] What evidence would justify using Perceptrons, Layers, and Shapes in an offline environmental dataset? Name a baseline, a metric or invariant, and a failure case.
7. [practice] [NAA-17-01-062] Design a five-step offline activity that teaches Perceptrons, Layers, and Shapes through an offline environmental dataset. Include an observable mastery check.
8. [challenge] [NAA-17-01-072] X has shape (5, 3) and W has shape (3, 3). What is the shape of X @ W?
9. [challenge] [NAA-17-01-082] Evaluate this claim: 'Perceptrons, Layers, and Shapes guarantees a correct or fair result for an offline environmental dataset.' Give a precise correction and evidence plan.
10. [challenge] [NAA-17-01-092] Extend Perceptrons, Layers, and Shapes from a tiny example to an offline environmental dataset. Identify a scaling risk, an evaluation risk, and a responsible-use constraint.

## Mastery check

You are ready to continue when you can explain the key idea without notes, complete at least 8 of the 10 practice tasks, reproduce the worked example, and explain one failure case. The answer key is stored separately so the app can reveal it after submission.
