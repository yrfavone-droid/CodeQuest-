# Answer Key - S18-L01: Images as Tensors

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 3

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 4

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 5

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 6

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 7

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 9

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).

## 10

**Answer:** The response should accurately use images, tensors, interpret, pixels; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A digital image is a grid of numeric channel values. Libraries may use height-width-channel or channel-height-width order, and normalization must match the model's training assumptions.

**Why:** An RGB image of 64 by 64 contains three channels and may be represented as (3,64,64).
