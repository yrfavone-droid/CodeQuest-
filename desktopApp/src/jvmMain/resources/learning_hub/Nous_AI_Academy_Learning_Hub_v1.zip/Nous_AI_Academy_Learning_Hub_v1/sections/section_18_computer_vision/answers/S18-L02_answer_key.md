# Answer Key - S18-L02: Convolution and Pooling

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 3

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 4

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 5

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 6

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 7

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 9

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.

## 10

**Answer:** The response should accurately use convolution, pooling, explain, receptive; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Convolution applies the same local filter across positions, sharing weights and detecting patterns regardless of exact location. Stride and padding control output size; pooling summarizes neighborhoods.

**Why:** A 3x3 filter with padding 1 and stride 1 preserves spatial height and width.
