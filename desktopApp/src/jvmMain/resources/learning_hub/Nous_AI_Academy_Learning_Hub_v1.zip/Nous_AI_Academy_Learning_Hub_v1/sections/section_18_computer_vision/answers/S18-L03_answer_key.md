# Answer Key - S18-L03: CNN Architectures and Feature Hierarchies

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 3

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 4

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 5

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 6

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 7

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 9

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.

## 10

**Answer:** The response should accurately use architectures, feature, hierarchies, trace; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Early CNN layers often detect local edges or textures, while later layers combine them into task-specific patterns. Residual connections help gradients pass through deep networks.

**Why:** Spatial dimensions commonly decrease while channel count increases.
