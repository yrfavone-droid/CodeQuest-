# Answer Key - S18-L04: Augmentation and Transfer Learning

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** C

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 3

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 4

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 5

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 6

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 7

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 9

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.

## 10

**Answer:** The response should accurately use augmentation, transfer, learning, apply; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Augmentation should reflect plausible variations without changing the label. Transfer learning initializes from a model trained on another dataset, then freezes or fine-tunes layers using suitable learning rates.

**Why:** Horizontal flipping is valid for many objects but invalid when left-right orientation defines the label.
