# Answer Key - S18-L05: Vision Evaluation, Bias, and Deployment

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 3

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 4

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 5

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 6

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 7

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 9

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.

## 10

**Answer:** The response should accurately use vision, evaluation, bias, deployment; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Overall accuracy can hide failures by class, lighting, device, or background. Deployment must validate input shape, normalize consistently, measure latency, and detect drift.

**Why:** A model tested only on clean centered images may fail on real camera images.
