# Answer Key - S19-L01: Tokenization and Embeddings

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 3

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 4

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 5

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 6

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 7

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 9

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.

## 10

**Answer:** The response should accurately use tokenization, embeddings, convert, text; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Tokenizers split text into model units that may be words, subwords, or characters. Embeddings map discrete items to vectors where geometry can encode learned relationships.

**Why:** Rare words may be represented by multiple subword tokens, changing sequence length and cost.
