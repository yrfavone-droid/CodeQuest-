# Answer Key - S19-L02: Text Classification and Sequence Modeling

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 3

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 4

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 5

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 6

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 7

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 9

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.

## 10

**Answer:** The response should accurately use text, classification, sequence, modeling; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Bag-of-words models ignore order but are strong baselines; recurrent and convolutional sequence models add order or local context. Duplicate documents and source metadata can leak labels.

**Why:** A spam classifier may memorize a sender domain rather than message content.
