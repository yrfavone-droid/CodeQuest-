# Answer Key - S19-L03: Attention and Transformers

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 3

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 4

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 5

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 6

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 7

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 9

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.

## 10

**Answer:** The response should accurately use attention, transformers, explain, queries; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Scaled dot-product attention compares queries with keys, converts scores to weights, and combines values. Multi-head attention learns several relationship patterns; positional information supplies order.

**Why:** Each token can attend to relevant earlier or later tokens, subject to the model's mask.
