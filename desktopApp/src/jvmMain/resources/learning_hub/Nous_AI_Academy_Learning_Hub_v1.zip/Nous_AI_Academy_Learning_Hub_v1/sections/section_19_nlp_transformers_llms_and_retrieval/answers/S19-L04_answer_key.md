# Answer Key - S19-L04: LLM Generation, Prompting, and Evaluation

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 3

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 4

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 5

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 6

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 7

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 9

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.

## 10

**Answer:** The response should accurately use generation, prompting, evaluation, control; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A language model predicts token distributions; temperature and sampling affect diversity. Prompts provide instructions and context but do not guarantee truth, so evaluation needs task-specific references, tests, or human review.

**Why:** Lower temperature can reduce variability but cannot make unsupported knowledge reliable.
