# Answer Key - S19-L05: RAG and Vector Search

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** D

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 3

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 4

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 5

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 6

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 7

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 9

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.

## 10

**Answer:** The response should accurately use vector, search, build, retrieval augmented; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: RAG chunks documents, embeds chunks, retrieves relevant evidence, and asks a generator to answer from that evidence. Retrieval recall, chunk boundaries, metadata, and citation validation all affect quality.

**Why:** A correct document in storage is useless if chunking separates the question term from the needed explanation.
