# Answer Key - S20-L01: States, Actions, Rewards, and Policies

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 3

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 4

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 5

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 6

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 7

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 9

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.

## 10

**Answer:** The response should accurately use states, actions, rewards, policies; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: An MDP specifies states, actions, transitions, rewards, and a discount factor. A policy maps states to action choices, while return sums discounted future rewards.

**Why:** A study scheduler state can include completed topics, but reward design must avoid encouraging meaningless rapid clicks.
