# Answer Key - S20-L02: Exploration and Q-Learning

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 3

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 4

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 5

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 6

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 7

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 9

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.

## 10

**Answer:** The response should accurately use exploration, q learning, update, action; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Q-learning updates a state-action value toward reward plus the discounted best next value. Epsilon-greedy behavior explores randomly with probability epsilon and exploits otherwise.

**Why:** If exploration stops too early, an agent may never discover a better route.
