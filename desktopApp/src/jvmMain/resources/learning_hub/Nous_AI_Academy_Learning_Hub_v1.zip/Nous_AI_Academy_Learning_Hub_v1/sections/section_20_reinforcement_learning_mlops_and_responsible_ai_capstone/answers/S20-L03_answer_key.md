# Answer Key - S20-L03: Experiment Tracking and Versioning

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** B

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 3

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 4

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 5

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 6

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 7

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 9

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.

## 10

**Answer:** The response should accurately use experiment, tracking, versioning, make; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: A reproducible run records dataset version, code revision, environment, seed, hyperparameters, metrics, and output checksum. A model should never be separated from the preprocessing and schema it expects.

**Why:** Two files named model_final are not version control and cannot explain which data produced them.
