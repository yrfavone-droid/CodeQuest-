# Answer Key - S20-L04: Deployment, Monitoring, and Drift

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 3

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 4

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 5

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 6

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 7

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 9

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.

## 10

**Answer:** The response should accurately use deployment, monitoring, drift, package; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Deployment validates inputs, applies the exact training transformations, returns structured errors, and logs allowed diagnostics. Data drift changes inputs; concept drift changes the relationship between inputs and targets.

**Why:** A stable input distribution can still accompany concept drift if user behavior changes label meaning.
