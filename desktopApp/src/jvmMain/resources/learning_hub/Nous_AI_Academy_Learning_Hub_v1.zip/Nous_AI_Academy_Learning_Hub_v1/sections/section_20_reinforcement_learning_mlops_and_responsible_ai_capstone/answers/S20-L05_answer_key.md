# Answer Key - S20-L05: Fairness, Privacy, Explainability, and Capstone

Use rubric answers to evaluate reasoning, not exact wording.

## 1

**Answer:** A

**Why:** The correct choice states the lesson's actual mechanism and preserves evidence, assumptions, and validation.

## 2

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 3

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 4

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 5

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 6

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 7

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 8

**Answer:** The example must be internally consistent, show intermediate work, and demonstrate this principle: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 9

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.

## 10

**Answer:** The response should accurately use fairness, privacy, explainability, capstone; apply the mechanism rather than only naming it; state an assumption; and include a check. Core reference: Responsible AI considers performance across affected groups, data minimization, consent, security, explainability, contestability, and human oversight. Fairness metrics can conflict, so the chosen definition must match the context.

**Why:** Removing a sensitive column does not guarantee fairness because proxy features may preserve the same information.
