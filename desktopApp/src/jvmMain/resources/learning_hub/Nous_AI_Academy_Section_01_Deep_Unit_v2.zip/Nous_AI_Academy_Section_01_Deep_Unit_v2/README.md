# Nous AI Academy - Section 01 Deep Unit

This package replaces only Section 1 of the Learning Hub with a deep, original article-based curriculum.

## Product content

- 5 long article lessons with 8 teaching units each
- 40 embedded knowledge checks with answers
- 400 practice tasks and 100 lesson-quiz tasks using stable existing IDs
- 5 applied projects and complete student notes
- 5 quick sheets, 5 answer guides, and a 30-question unit assessment
- 5 lesson PDFs plus one combined master PDF
- structured article blocks for the app, an offline SQLite content database, checksums, and import safeguards

Every lesson page should present: title and progress, a table of contents, long article units, worked cases, misconception callouts, revealable checks, note-taking, practice, quiz, project, glossary, and completion requirements.

No third-party lesson text is copied. The content is original to Nous AI Academy and works without a network or paid service.
