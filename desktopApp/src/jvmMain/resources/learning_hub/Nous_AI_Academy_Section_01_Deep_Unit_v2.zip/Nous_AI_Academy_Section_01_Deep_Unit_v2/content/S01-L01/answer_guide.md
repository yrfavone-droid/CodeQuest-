# Answer Guide - S01-L01: AI, Machine Learning, Deep Learning, and Generative AI

Rubric answers evaluate reasoning, not exact wording.

## Embedded checks

### 1. A program follows hand-written rules to schedule classrooms. Is it necessarily machine learning? Explain.

No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### 2. Give one reason to prefer a rule and one reason to prefer a learned model for sorting messages.

Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### 3. What is the difference between a model parameter and a prediction?

A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### 4. Why should a team compare a deep network with a simpler baseline?

The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### 5. Does lowering generation temperature guarantee factual answers? Why or why not?

No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### 6. Adding a PDF to a retrieval index changes which part of an AI system?

It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### 7. List the five facts you need before classifying an unfamiliar product as ML or generative AI.

Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### 8. Rewrite the claim 'Our AI always finds the perfect lesson' as an honest, testable claim.

Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

## Practice answers and rubrics

### NAA-01-01-001

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-002

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-003

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-004

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-005

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-006

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-007

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-008

**Answer/rubric:** C

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules. The tempting error is: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

### NAA-01-01-009

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-010

**Answer/rubric:** A complete response must accurately use this reference idea: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It should address the worked-case evidence: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. It must not repeat this misconception: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-011

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-012

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-013

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-014

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-015

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-016

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-017

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-018

**Answer/rubric:** C

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist. The tempting error is: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

### NAA-01-01-019

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-020

**Answer/rubric:** A complete response must accurately use this reference idea: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It should address the worked-case evidence: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. It must not repeat this misconception: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-021

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-022

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-023

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-024

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-025

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-026

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-027

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-028

**Answer/rubric:** A

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input. The tempting error is: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

### NAA-01-01-029

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-030

**Answer/rubric:** A complete response must accurately use this reference idea: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It should address the worked-case evidence: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. It must not repeat this misconception: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-031

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-032

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-033

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-034

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-035

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-036

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-037

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-038

**Answer/rubric:** C

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs. The tempting error is: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

### NAA-01-01-039

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-040

**Answer/rubric:** A complete response must accurately use this reference idea: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It should address the worked-case evidence: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. It must not repeat this misconception: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### NAA-01-01-041

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-042

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-043

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-044

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-045

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-046

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-047

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-048

**Answer/rubric:** D

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern. The tempting error is: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

### NAA-01-01-049

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-050

**Answer/rubric:** A complete response must accurately use this reference idea: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It should address the worked-case evidence: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. It must not repeat this misconception: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-051

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-052

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-053

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-054

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-055

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-056

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-057

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-058

**Answer/rubric:** D

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters. The tempting error is: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

### NAA-01-01-059

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-060

**Answer/rubric:** A complete response must accurately use this reference idea: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It should address the worked-case evidence: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. It must not repeat this misconception: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-061

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-062

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-063

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-064

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-065

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-066

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-067

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-068

**Answer/rubric:** D

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed. The tempting error is: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

### NAA-01-01-069

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-070

**Answer/rubric:** A complete response must accurately use this reference idea: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It should address the worked-case evidence: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. It must not repeat this misconception: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-071

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-072

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-073

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-074

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-075

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-076

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-077

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-078

**Answer/rubric:** D

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.' The tempting error is: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

### NAA-01-01-079

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-080

**Answer/rubric:** A complete response must accurately use this reference idea: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It should address the worked-case evidence: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. It must not repeat this misconception: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

## Quiz answers

### NAA-01-01-081

**Answer/rubric:** C

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules. The tempting error is: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

### NAA-01-01-082

**Answer/rubric:** D

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist. The tempting error is: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

### NAA-01-01-083

**Answer/rubric:** D

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input. The tempting error is: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

### NAA-01-01-084

**Answer/rubric:** A

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs. The tempting error is: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

### NAA-01-01-085

**Answer/rubric:** B

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern. The tempting error is: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

### NAA-01-01-086

**Answer/rubric:** A

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters. The tempting error is: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

### NAA-01-01-087

**Answer/rubric:** B

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed. The tempting error is: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

### NAA-01-01-088

**Answer/rubric:** B

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.' The tempting error is: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

### NAA-01-01-089

**Answer/rubric:** A

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules. The tempting error is: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

### NAA-01-01-090

**Answer/rubric:** D

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist. The tempting error is: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

### NAA-01-01-091

**Answer/rubric:** D

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input. The tempting error is: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

### NAA-01-01-092

**Answer/rubric:** D

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs. The tempting error is: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

### NAA-01-01-093

**Answer/rubric:** The response must accurately use: A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters. It must include evidence consistent with: A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked. and correct: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

**Explanation:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### NAA-01-01-094

**Answer/rubric:** The response must accurately use: Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model. It must include evidence consistent with: An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged. and correct: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

**Explanation:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### NAA-01-01-095

**Answer/rubric:** The response must accurately use: Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component. It must include evidence consistent with: A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system. and correct: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

**Explanation:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### NAA-01-01-096

**Answer/rubric:** The response must accurately use: AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements. It must include evidence consistent with: A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability. and correct: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

**Explanation:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

### NAA-01-01-097

**Answer/rubric:** The response must accurately use: Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful. It must include evidence consistent with: A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI. and correct: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

**Explanation:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### NAA-01-01-098

**Answer/rubric:** The response must accurately use: Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses. It must include evidence consistent with: A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem. and correct: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

**Explanation:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### NAA-01-01-099

**Answer/rubric:** The response must accurately use: Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation. It must include evidence consistent with: A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction. and correct: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

**Explanation:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### NAA-01-01-100

**Answer/rubric:** The response must accurately use: Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models. It must include evidence consistent with: A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more. and correct: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

**Explanation:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.
