# S01-L01: AI, Machine Learning, Deep Learning, and Generative AI

## Build a precise map of the field before learning its tools

**Academy:** Nous AI Academy  
**Format:** Deep Article Lesson  
**Estimated study time:** 3-5 hours across multiple sessions  
**Offline:** Fully supported

## Big question

What kind of system are we building, and what evidence would justify calling it AI, machine learning, deep learning, or generative AI?

## Learning objectives

- Distinguish AI, machine learning, deep learning, and generative AI without treating the terms as synonyms.
- Separate rule-based automation from systems that learn parameters from examples.
- Explain training, inference, discriminative prediction, and generation in plain language.
- Classify a real system from evidence about how it works rather than from marketing language.
- Identify limitations, human responsibilities, and evaluation needs for an AI claim.

## How to study this lesson

Read one article unit at a time. Before revealing each check answer, write your prediction. Reproduce the worked case, change one condition, and explain what changes. After the article, complete the notes from memory, then use the practice bank. Attempt the lesson quiz only after reaching at least 80% mastery on the selected practice set.

The goal is not to memorize vocabulary. The goal is to trace mechanisms, test claims, identify assumptions, and produce evidence another learner can inspect.

## 1. Artificial intelligence is a goal, not one algorithm

### Core explanation

Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support. The label does not reveal the mechanism. A chess program built from search rules, a medical-image classifier trained from labeled examples, and a language model that generates text can all be described as AI, but they work differently. A precise explanation therefore begins with the task, input, output, mechanism, and evidence. The important question is not whether a product feels intelligent. The important question is what operations produce its behavior and under which conditions the behavior remains useful.

### Deep reasoning

To reason well about artificial intelligence is a goal, not one algorithm, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, artificial intelligence is a goal, not one algorithm also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A route planner receives a map, a starting point, and a destination. It searches possible paths under a cost rule. It may be an AI system even if it does not learn from historical journeys, because intelligent search and planning are part of AI.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** A program follows hand-written rules to schedule classrooms. Is it necessarily machine learning? Explain.

<details>
<summary>Reveal answer</summary>

No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

</details>

### Practice before continuing

- **NAA-01-01-001** Explain Artificial intelligence is a goal, not one algorithm in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-002** Apply Artificial intelligence is a goal, not one algorithm to an offline study assistant. Name the input, operation, output, and one validation check.
- **NAA-01-01-003** Compare a correct use of Artificial intelligence is a goal, not one algorithm with the misconception below: 'Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.' Explain the consequence of the mistake.
- **NAA-01-01-004** Create a small trace for Artificial intelligence is a goal, not one algorithm in a plant-image learning project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 2. Automation, rules, and learned behavior

### Core explanation

Automation repeats a defined process. A rule-based system applies conditions written by people, such as assigning a warning when a sensor crosses a threshold. Machine learning instead chooses parameter values by optimizing performance on examples. The boundary is not always visible from the interface: two tools can display the same result while one uses rules and the other uses a fitted model. Hybrid systems are common. They may validate inputs with rules, predict with a model, and apply safety rules to the output. Understanding the boundary helps teams debug failures because a broken rule, a distribution shift, and a poorly fitted model require different responses.

### Deep reasoning

To reason well about automation, rules, and learned behavior, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, automation, rules, and learned behavior also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A study assistant may use a learned classifier to estimate which concept a question tests, then use fixed rules to prevent it from revealing an answer before a learner attempts the problem.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Give one reason to prefer a rule and one reason to prefer a learned model for sorting messages.

<details>
<summary>Reveal answer</summary>

Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

</details>

### Practice before continuing

- **NAA-01-01-011** Explain Automation, rules, and learned behavior in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-012** Apply Automation, rules, and learned behavior to a school resource planner. Name the input, operation, output, and one validation check.
- **NAA-01-01-013** Compare a correct use of Automation, rules, and learned behavior with the misconception below: 'Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.' Explain the consequence of the mistake.
- **NAA-01-01-014** Create a small trace for Automation, rules, and learned behavior in a local library search tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## 3. Machine learning: fitting patterns from examples

### Core explanation

Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data. In supervised learning, the data includes examples and target labels. During training, the procedure searches for parameters that reduce a loss on training examples. During inference, the fitted model processes a new input without changing its parameters. Success on training data is insufficient because a model can memorize details that do not generalize. Evaluation must use held-out examples that represent the intended operating conditions. The model's output can be a number, category, ranking, probability estimate, or action recommendation.

### Deep reasoning

To reason well about machine learning: fitting patterns from examples, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, machine learning: fitting patterns from examples also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A linear model can learn weights for hours studied, previous quiz score, and missed assignments. Training estimates the weights; inference combines a new learner's features with the fixed weights to produce a prediction.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What is the difference between a model parameter and a prediction?

<details>
<summary>Reveal answer</summary>

A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

</details>

### Practice before continuing

- **NAA-01-01-021** Explain Machine learning: fitting patterns from examples in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-022** Apply Machine learning: fitting patterns from examples to a plant-image learning project. Name the input, operation, output, and one validation check.
- **NAA-01-01-023** Compare a correct use of Machine learning: fitting patterns from examples with the misconception below: 'Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.' Explain the consequence of the mistake.
- **NAA-01-01-024** Create a small trace for Machine learning: fitting patterns from examples in an environmental sensor project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 4. Deep learning: multilayer representation learning

### Core explanation

Deep learning is machine learning based on neural networks with multiple computational layers. Each layer transforms a representation into another representation. During training, gradient-based optimization adjusts many weights so later layers become useful for the objective. In image systems, early layers may respond to local edges or textures while later combinations support task-specific distinctions. This description is an interpretation, not a guarantee that every unit has a simple human meaning. Deep networks are powerful because they can learn useful representations directly from high-dimensional inputs, but they often require more data, computation, and careful evaluation than simpler models.

### Deep reasoning

To reason well about deep learning: multilayer representation learning, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, deep learning: multilayer representation learning also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A small tabular dataset may work well with a tree or linear model. A large collection of varied images may benefit from a convolutional network or a pretrained vision model because representation learning matters more.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why should a team compare a deep network with a simpler baseline?

<details>
<summary>Reveal answer</summary>

The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

</details>

### Practice before continuing

- **NAA-01-01-031** Explain Deep learning: multilayer representation learning in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-032** Apply Deep learning: multilayer representation learning to a local library search tool. Name the input, operation, output, and one validation check.
- **NAA-01-01-033** Compare a correct use of Deep learning: multilayer representation learning with the misconception below: 'Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.' Explain the consequence of the mistake.
- **NAA-01-01-034** Create a small trace for Deep learning: multilayer representation learning in a language-learning application. Show the initial state, two meaningful transformations, the result, and an independent check.

## 5. Discriminative and generative modeling

### Core explanation

A discriminative model focuses on predicting a target from an input, such as a class from an image. A generative model represents enough structure to create or score possible data, such as producing text, images, audio, or synthetic records. Modern generative systems learn distributions from large datasets and then sample outputs conditioned on prompts or other inputs. Generated content is not retrieved truth simply because it is fluent. The model selects likely continuations under its training and decoding process. Grounding, verification, and clear uncertainty are required when correctness matters.

### Deep reasoning

To reason well about discriminative and generative modeling, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, discriminative and generative modeling also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A classifier decides whether a review is positive or negative. A language model can generate a new review-like paragraph. A retrieval system can supply documents to the generator, but the final wording is still generated and must be checked.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Does lowering generation temperature guarantee factual answers? Why or why not?

<details>
<summary>Reveal answer</summary>

No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

</details>

### Practice before continuing

- **NAA-01-01-041** Explain Discriminative and generative modeling in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-042** Apply Discriminative and generative modeling to an environmental sensor project. Name the input, operation, output, and one validation check.
- **NAA-01-01-043** Compare a correct use of Discriminative and generative modeling with the misconception below: 'Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.' Explain the consequence of the mistake.
- **NAA-01-01-044** Create a small trace for Discriminative and generative modeling in a transport-delay analysis. Show the initial state, two meaningful transformations, the result, and an independent check.

## 6. Training, inference, adaptation, and updates

### Core explanation

Training changes model parameters using an objective and examples. Inference applies parameters to inputs. Some systems also adapt through fine-tuning, preference optimization, retrieval updates, or user-specific state. These processes must be distinguished because they have different privacy, cost, and validation implications. A chatbot remembering a name in local session storage is not necessarily retraining its language model. Adding documents to a retrieval index changes available context but not the base model's weights. Precise system diagrams prevent teams from claiming that every user interaction teaches the model.

### Deep reasoning

To reason well about training, inference, adaptation, and updates, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, training, inference, adaptation, and updates also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

An offline tutor stores a learner's mastery locally and chooses questions from that state. The selection adapts to the learner even if the prediction model is unchanged.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Adding a PDF to a retrieval index changes which part of an AI system?

<details>
<summary>Reveal answer</summary>

It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

</details>

### Practice before continuing

- **NAA-01-01-051** Explain Training, inference, adaptation, and updates in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-052** Apply Training, inference, adaptation, and updates to a language-learning application. Name the input, operation, output, and one validation check.
- **NAA-01-01-053** Compare a correct use of Training, inference, adaptation, and updates with the misconception below: 'Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.' Explain the consequence of the mistake.
- **NAA-01-01-054** Create a small trace for Training, inference, adaptation, and updates in a science-fair investigation. Show the initial state, two meaningful transformations, the result, and an independent check.

## 7. How to classify an AI system responsibly

### Core explanation

Classify a system by tracing evidence. First name the task and users. Next identify inputs and outputs. Then determine whether behavior comes from fixed rules, search, fitted parameters, retrieved information, generated samples, or a hybrid. Ask what changes during training and what remains fixed during use. Finally record evaluation conditions and human decision points. This method avoids arguments based on branding. It also reveals dependencies: a generative interface may rely on a retrieval model, ranking rules, filters, databases, and human review rather than one magical component.

### Deep reasoning

To reason well about how to classify an ai system responsibly, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, how to classify an ai system responsibly also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A photo-search feature may embed images with a deep model, find nearby vectors with an algorithm, filter results through permission rules, and present ranked items. Its correct classification is a hybrid AI system.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** List the five facts you need before classifying an unfamiliar product as ML or generative AI.

<details>
<summary>Reveal answer</summary>

Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

</details>

### Practice before continuing

- **NAA-01-01-061** Explain How to classify an AI system responsibly in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-062** Apply How to classify an AI system responsibly to a transport-delay analysis. Name the input, operation, output, and one validation check.
- **NAA-01-01-063** Compare a correct use of How to classify an AI system responsibly with the misconception below: 'Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.' Explain the consequence of the mistake.
- **NAA-01-01-064** Create a small trace for How to classify an AI system responsibly in a learner-progress dashboard. Show the initial state, two meaningful transformations, the result, and an independent check.

## 8. Limits, human judgment, and honest claims

### Core explanation

AI performance is conditional. Results depend on data quality, task definition, distribution, objective, threshold, interface, and human use. A model can be accurate on average and still fail for rare cases or underrepresented groups. Human oversight must be designed, not merely promised: reviewers need time, information, authority, and a way to challenge the system. Honest product language states what the system supports, what it does not decide, which evidence was collected, and when a person must take responsibility. This approach makes the product more trustworthy because limitations become testable requirements.

### Deep reasoning

To reason well about limits, human judgment, and honest claims, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, limits, human judgment, and honest claims also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For AI, Machine Learning, Deep Learning, and Generative AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A tutoring recommender can suggest the next lesson while allowing the learner or teacher to override it. The product should explain the evidence used and avoid presenting the recommendation as a permanent judgment of ability.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Rewrite the claim 'Our AI always finds the perfect lesson' as an honest, testable claim.

<details>
<summary>Reveal answer</summary>

Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

</details>

### Practice before continuing

- **NAA-01-01-071** Explain Limits, human judgment, and honest claims in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-01-072** Apply Limits, human judgment, and honest claims to a science-fair investigation. Name the input, operation, output, and one validation check.
- **NAA-01-01-073** Compare a correct use of Limits, human judgment, and honest claims with the misconception below: 'Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.' Explain the consequence of the mistake.
- **NAA-01-01-074** Create a small trace for Limits, human judgment, and honest claims in a small accessibility tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## Lesson synthesis

Use the following four-column method to connect the whole lesson:

| Concept | Mechanism | Evidence | Limitation |
|---|---|---|---|
| Artificial intelligence is a goal, not one algorithm | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data. |
| Automation, rules, and learned behavior | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test. |
| Machine learning: fitting patterns from examples | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels. |
| Deep learning: multilayer representation learning | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information. |
| Discriminative and generative modeling | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement. |
| Training, inference, adaptation, and updates | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation. |
| How to classify an AI system responsibly | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation. |
| Limits, human judgment, and honest claims | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight. |

## Applied project

Create an AI-system map for one familiar product. Draw its inputs, rule-based components, learned components, stored information, outputs, evaluation evidence, and human control points. Include one claim you can support and one claim you must reject.

### Required project evidence

- A one-page specification
- A mechanism or component diagram
- One worked example with intermediate states
- One boundary case and one preserved failure
- A baseline or invariant
- A limitations and responsibility statement

## Glossary

- **artificial intelligence:** The broad field of systems that perform tasks involving perception, language, prediction, planning, search, or decision support.
- **automation:** Execution of a defined process with limited or no human intervention.
- **machine learning:** Methods that estimate model parameters from data to improve an objective.
- **deep learning:** Machine learning using multilayer neural networks.
- **generative AI:** Models that produce new content by sampling from learned distributions, often conditioned on input.
- **training:** The process that estimates or updates model parameters.
- **inference:** Applying a fitted model to an input to produce an output.
- **parameter:** An internal value learned or selected during model fitting.
- **baseline:** A simple reference method used to judge whether complexity adds value.
- **generalization:** Performance on relevant examples not used to fit the model.

## Lesson quiz

Complete the quiz without notes. Multiple-choice items are scored automatically; written items use the provided rubric after submission.

1. **NAA-01-01-081** A program follows hand-written rules to schedule classrooms. Is it necessarily machine learning? Explain.
   - A. Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.
   - D. The newest or most complex method should be selected before defining the task and constraints.
2. **NAA-01-01-082** Give one reason to prefer a rule and one reason to prefer a learned model for sorting messages.
   - A. Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.
3. **NAA-01-01-083** What is the difference between a model parameter and a prediction?
   - A. Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.
4. **NAA-01-01-084** Why should a team compare a deep network with a simpler baseline?
   - A. The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.
5. **NAA-01-01-085** Does lowering generation temperature guarantee factual answers? Why or why not?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Treating generation as database lookup. A model can produce a plausible statement that was never stored as one exact sentence and may produce an unsupported statement.
6. **NAA-01-01-086** Adding a PDF to a retrieval index changes which part of an AI system?
   - A. It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Claiming a model learns instantly from every correction. Many deployed systems log feedback for later review rather than updating weights during the conversation.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
7. **NAA-01-01-087** List the five facts you need before classifying an unfamiliar product as ML or generative AI.
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Forcing one label onto the whole product. Different components can use different mechanisms and deserve separate evaluation.
8. **NAA-01-01-088** Rewrite the claim 'Our AI always finds the perfect lesson' as an honest, testable claim.
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'
   - C. Using the phrase human in the loop without defining the person's role. A nominal reviewer who cannot inspect evidence or change the result is not meaningful oversight.
   - D. The newest or most complex method should be selected before defining the task and constraints.
9. **NAA-01-01-089** Which response best corrects this misconception about Artificial intelligence is a goal, not one algorithm: 'Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.'?
   - A. No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Calling every complex program machine learning. Complexity does not imply learning; a program can execute millions of fixed rules without estimating parameters from data.
10. **NAA-01-01-090** Which response best corrects this misconception about Automation, rules, and learned behavior: 'Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.'?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. Assuming learned systems are always better than rules. When a policy is stable, transparent, and easy to specify, a rule may be cheaper, safer, and easier to test.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.
11. **NAA-01-01-091** Which response best corrects this misconception about Machine learning: fitting patterns from examples: 'Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.'?
   - A. Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.
12. **NAA-01-01-092** Which response best corrects this misconception about Deep learning: multilayer representation learning: 'Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. Believing deep means automatically accurate or advanced. A deep model can be worse than a baseline if the dataset is small, labels are unreliable, or evaluation leaks information.
   - D. The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.
13. **NAA-01-01-093** Use a plant-image learning project to explain Discriminative and generative modeling through a complete input-to-output chain.
14. **NAA-01-01-094** Evaluate a confident product claim about Training, inference, adaptation, and updates and rewrite it as a narrow, testable claim.
15. **NAA-01-01-095** Design one boundary test and one failure-regression test for How to classify an AI system responsibly.
16. **NAA-01-01-096** Connect Limits, human judgment, and honest claims to another idea in this lesson and explain why the connection matters.
17. **NAA-01-01-097** Propose an offline mini-project that demonstrates Artificial intelligence is a goal, not one algorithm with saved evidence.
18. **NAA-01-01-098** Explain what a responsible human reviewer should inspect before accepting a result involving Automation, rules, and learned behavior.
19. **NAA-01-01-099** Give a counterexample to the misconception 'Saying the model learned the truth. A model learns a parameterized pattern under its data, objective, and assumptions. It can exploit shortcuts or reproduce errors in labels.' and explain the corrected rule.
20. **NAA-01-01-100** Write a six-sentence mastery explanation of Deep learning: multilayer representation learning for a learner who has never studied AI.

## Completion rule

A lesson is complete when the learner reads all eight units, answers each embedded check, submits the notes, masters at least 64 of 80 practice tasks, scores at least 16 of 20 on the quiz or completes corrections, and submits the applied project evidence.
