# Quick Sheet - S01-L01: AI, Machine Learning, Deep Learning, and Generative AI

**Big question:** What kind of system are we building, and what evidence would justify calling it AI, machine learning, deep learning, or generative AI?

## Essential ideas

### Artificial intelligence is a goal, not one algorithm

Artificial intelligence is a broad engineering and scientific goal: create systems that perform tasks involving perception, language, prediction, planning, search, or decision support.

**Remember:** No. It can be AI-style planning or ordinary automation, but it is machine learning only if it estimates behavior or parameters from data rather than only executing fixed rules.

### Automation, rules, and learned behavior

Automation repeats a defined process.

**Remember:** Prefer a rule when a stable exact condition defines the category. Prefer a learned model when useful patterns are too varied to list manually and enough representative labeled examples exist.

### Machine learning: fitting patterns from examples

Machine learning defines a model family, an objective, and a procedure that adjusts parameters using data.

**Remember:** A parameter is a learned internal value reused across examples. A prediction is an output produced when those fixed parameters are applied to a particular input.

### Deep learning: multilayer representation learning

Deep learning is machine learning based on neural networks with multiple computational layers.

**Remember:** The comparison shows whether added complexity improves held-out performance enough to justify extra computation, data needs, maintenance, and interpretability costs.

### Discriminative and generative modeling

A discriminative model focuses on predicting a target from an input, such as a class from an image.

**Remember:** No. Lower temperature usually reduces randomness, but it does not add missing evidence or correct a mistaken learned pattern.

### Training, inference, adaptation, and updates

Training changes model parameters using an objective and examples.

**Remember:** It changes the searchable knowledge source and the context supplied at inference; it does not automatically change the base model parameters.

### How to classify an AI system responsibly

Classify a system by tracing evidence.

**Remember:** Task and users; inputs and outputs; mechanism; what is learned or updated; and evidence/operating conditions. A component diagram is often also needed.

### Limits, human judgment, and honest claims

AI performance is conditional.

**Remember:** Example: 'The recommender ranks lessons from locally recorded mastery signals; on our stated pilot set it improved the selected learning metric over a baseline, and learners can inspect and override every recommendation.'

## Universal reasoning checklist

1. Define the task and unit.
2. Separate inputs, operations, outputs, and constraints.
3. Predict before computing.
4. Compare with a baseline or invariant.
5. Test a boundary and preserve failures.
6. State evidence, limitations, and human responsibility.
