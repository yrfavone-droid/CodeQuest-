# Student Notes - S01-L01: AI, Machine Learning, Deep Learning, and Generative AI

Complete these notes from memory before reopening the article.

## Big question

What kind of system are we building, and what evidence would justify calling it AI, machine learning, deep learning, or generative AI?

## Retrieval notes

### 1. Artificial intelligence is a goal, not one algorithm

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** A program follows hand-written rules to schedule classrooms. Is it necessarily machine learning? Explain.

**My answer:**

---

### 2. Automation, rules, and learned behavior

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Give one reason to prefer a rule and one reason to prefer a learned model for sorting messages.

**My answer:**

---

### 3. Machine learning: fitting patterns from examples

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What is the difference between a model parameter and a prediction?

**My answer:**

---

### 4. Deep learning: multilayer representation learning

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why should a team compare a deep network with a simpler baseline?

**My answer:**

---

### 5. Discriminative and generative modeling

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Does lowering generation temperature guarantee factual answers? Why or why not?

**My answer:**

---

### 6. Training, inference, adaptation, and updates

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Adding a PDF to a retrieval index changes which part of an AI system?

**My answer:**

---

### 7. How to classify an AI system responsibly

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** List the five facts you need before classifying an unfamiliar product as ML or generative AI.

**My answer:**

---

### 8. Limits, human judgment, and honest claims

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Rewrite the claim 'Our AI always finds the perfect lesson' as an honest, testable claim.

**My answer:**

---

## Final one-page explanation

Explain the entire lesson to a new learner without using unexplained vocabulary. Include one diagram, one worked example, one counterexample, and one honest limitation.
