# Answer Guide - S01-L02: Problem Decomposition and Algorithms

Rubric answers evaluate reasoning, not exact wording.

## Embedded checks

### 1. Turn 'make a smart school app' into one testable computational problem.

A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### 2. Why is 'future quiz score' an invalid input for choosing a lesson before the quiz?

It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### 3. What should an interface specify besides the names of inputs and outputs?

Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### 4. What makes a step such as 'choose a similar example' ambiguous?

The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### 5. State an invariant for counting valid records in a list.

After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### 6. Give three boundary tests for selecting the smallest number.

An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### 7. When is an O(n log n) algorithm not automatically better than an O(n squared) one?

For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### 8. What should be frozen before comparing two algorithm implementations?

The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

## Practice answers and rubrics

### NAA-01-02-001

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-002

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-003

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-004

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-005

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-006

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-007

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-008

**Answer/rubric:** B

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement. The tempting error is: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

### NAA-01-02-009

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-010

**Answer/rubric:** A complete response must accurately use this reference idea: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It should address the worked-case evidence: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. It must not repeat this misconception: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-011

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-012

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-013

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-014

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-015

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-016

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-017

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-018

**Answer/rubric:** A

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage. The tempting error is: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

### NAA-01-02-019

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-020

**Answer/rubric:** A complete response must accurately use this reference idea: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It should address the worked-case evidence: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. It must not repeat this misconception: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-021

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-022

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-023

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-024

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-025

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-026

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-027

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-028

**Answer/rubric:** B

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on. The tempting error is: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

### NAA-01-02-029

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-030

**Answer/rubric:** A complete response must accurately use this reference idea: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It should address the worked-case evidence: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. It must not repeat this misconception: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-031

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-032

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-033

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-034

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-035

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-036

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-037

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-038

**Answer/rubric:** A

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified. The tempting error is: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

### NAA-01-02-039

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-040

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It should address the worked-case evidence: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. It must not repeat this misconception: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### NAA-01-02-041

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-042

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-043

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-044

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-045

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-046

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-047

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-048

**Answer/rubric:** B

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records. The tempting error is: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

### NAA-01-02-049

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-050

**Answer/rubric:** A complete response must accurately use this reference idea: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It should address the worked-case evidence: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. It must not repeat this misconception: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-051

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-052

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-053

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-054

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-055

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-056

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-057

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-058

**Answer/rubric:** A

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests. The tempting error is: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

### NAA-01-02-059

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-060

**Answer/rubric:** A complete response must accurately use this reference idea: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It should address the worked-case evidence: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. It must not repeat this misconception: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-061

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-062

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-063

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-064

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-065

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-066

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-067

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-068

**Answer/rubric:** D

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime. The tempting error is: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

### NAA-01-02-069

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-070

**Answer/rubric:** A complete response must accurately use this reference idea: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It should address the worked-case evidence: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. It must not repeat this misconception: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-071

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-072

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-073

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-074

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-075

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-076

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-077

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-078

**Answer/rubric:** D

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison. The tempting error is: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

### NAA-01-02-079

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-080

**Answer/rubric:** A complete response must accurately use this reference idea: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It should address the worked-case evidence: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. It must not repeat this misconception: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

## Quiz answers

### NAA-01-02-081

**Answer/rubric:** B

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement. The tempting error is: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

### NAA-01-02-082

**Answer/rubric:** A

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage. The tempting error is: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

### NAA-01-02-083

**Answer/rubric:** C

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on. The tempting error is: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

### NAA-01-02-084

**Answer/rubric:** D

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified. The tempting error is: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

### NAA-01-02-085

**Answer/rubric:** D

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records. The tempting error is: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

### NAA-01-02-086

**Answer/rubric:** B

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests. The tempting error is: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

### NAA-01-02-087

**Answer/rubric:** B

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime. The tempting error is: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

### NAA-01-02-088

**Answer/rubric:** A

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison. The tempting error is: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

### NAA-01-02-089

**Answer/rubric:** A

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement. The tempting error is: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

### NAA-01-02-090

**Answer/rubric:** D

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage. The tempting error is: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

### NAA-01-02-091

**Answer/rubric:** A

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on. The tempting error is: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

### NAA-01-02-092

**Answer/rubric:** B

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified. The tempting error is: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

### NAA-01-02-093

**Answer/rubric:** The response must accurately use: Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm. It must include evidence consistent with: When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly. and correct: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

**Explanation:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### NAA-01-02-094

**Answer/rubric:** The response must accurately use: Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears. It must include evidence consistent with: A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts. and correct: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

**Explanation:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### NAA-01-02-095

**Answer/rubric:** The response must accurately use: Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details. It must include evidence consistent with: Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear. and correct: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

**Explanation:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### NAA-01-02-096

**Answer/rubric:** The response must accurately use: An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same. It must include evidence consistent with: A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks. and correct: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

**Explanation:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

### NAA-01-02-097

**Answer/rubric:** The response must accurately use: A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence. It must include evidence consistent with: For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline. and correct: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

**Explanation:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### NAA-01-02-098

**Answer/rubric:** The response must accurately use: Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide. It must include evidence consistent with: A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint. and correct: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

**Explanation:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### NAA-01-02-099

**Answer/rubric:** The response must accurately use: Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem. It must include evidence consistent with: A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example. and correct: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

**Explanation:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### NAA-01-02-100

**Answer/rubric:** The response must accurately use: An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language. It must include evidence consistent with: Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time. and correct: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

**Explanation:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.
