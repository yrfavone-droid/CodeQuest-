# S01-L02: Problem Decomposition and Algorithms

## Turn an unclear idea into a testable computational plan

**Academy:** Nous AI Academy  
**Format:** Deep Article Lesson  
**Estimated study time:** 3-5 hours across multiple sessions  
**Offline:** Fully supported

## Big question

How can we transform a real goal into small, precise, ordered, and testable steps before writing code?

## Learning objectives

- Define inputs, outputs, constraints, assumptions, and success criteria for a computational task.
- Decompose a system into components with clear interfaces.
- Express an algorithm using plain language, pseudocode, flow, and invariants.
- Trace an algorithm and identify ambiguity, boundary cases, and failure conditions.
- Compare alternative algorithms using correctness, cost, and maintainability.

## How to study this lesson

Read one article unit at a time. Before revealing each check answer, write your prediction. Reproduce the worked case, change one condition, and explain what changes. After the article, complete the notes from memory, then use the practice bank. Attempt the lesson quiz only after reaching at least 80% mastery on the selected practice set.

The goal is not to memorize vocabulary. The goal is to trace mechanisms, test claims, identify assumptions, and produce evidence another learner can inspect.

## 1. From goals to computational problems

### Core explanation

A real goal such as help learners study better is not yet a computational problem. A specification names the user, decision, unit of analysis, available inputs, desired output, constraints, and measurable success. It also states what the system must not do. Clear framing prevents a team from optimizing a convenient metric that does not serve the original goal. The first version should be small enough to evaluate. A question like which lesson should be shown next is more precise than improve education, but it still requires a definition of mastery and a rule for insufficient evidence.

### Deep reasoning

To reason well about from goals to computational problems, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, from goals to computational problems also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

For an offline tutor, inputs may be completed attempts and timestamps; output may be a ranked lesson list; constraints include no internet and preserving local privacy; success may be improved quiz mastery compared with a simple sequence baseline.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Turn 'make a smart school app' into one testable computational problem.

<details>
<summary>Reveal answer</summary>

A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

</details>

### Practice before continuing

- **NAA-01-02-001** Explain From goals to computational problems in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-002** Apply From goals to computational problems to an offline study assistant. Name the input, operation, output, and one validation check.
- **NAA-01-02-003** Compare a correct use of From goals to computational problems with the misconception below: 'Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.' Explain the consequence of the mistake.
- **NAA-01-02-004** Create a small trace for From goals to computational problems in a plant-image learning project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 2. Inputs, outputs, constraints, and assumptions

### Core explanation

Inputs are the information available at the moment of computation. Outputs are the observable results. Constraints limit time, memory, privacy, hardware, or allowed behavior. Assumptions describe conditions taken as true for the design. Confusing these categories causes hidden leakage: information collected after a decision cannot be treated as input available before it. Every field needs a type, unit, allowed range, and missing-value rule. Outputs also need contracts, including what happens when the system cannot decide.

### Deep reasoning

To reason well about inputs, outputs, constraints, and assumptions, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, inputs, outputs, constraints, and assumptions also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A classifier that predicts before an exam cannot use the final exam score as a feature. The score exists in the database later but violates the prediction-time constraint.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why is 'future quiz score' an invalid input for choosing a lesson before the quiz?

<details>
<summary>Reveal answer</summary>

It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

</details>

### Practice before continuing

- **NAA-01-02-011** Explain Inputs, outputs, constraints, and assumptions in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-012** Apply Inputs, outputs, constraints, and assumptions to a school resource planner. Name the input, operation, output, and one validation check.
- **NAA-01-02-013** Compare a correct use of Inputs, outputs, constraints, and assumptions with the misconception below: 'Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.' Explain the consequence of the mistake.
- **NAA-01-02-014** Create a small trace for Inputs, outputs, constraints, and assumptions in a local library search tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## 3. Decomposition and interfaces

### Core explanation

Decomposition breaks a system into responsibilities that can be understood and tested separately. Good components communicate through explicit interfaces: required inputs, returned outputs, errors, and invariants. A useful decomposition often separates data loading, validation, transformation, decision logic, persistence, and presentation. The purpose is not to create the maximum number of files. It is to localize change and failure. If validation is mixed with ranking and display code, a malformed record may be misdiagnosed as a model problem.

### Deep reasoning

To reason well about decomposition and interfaces, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, decomposition and interfaces also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A lesson recommender can contain load_progress, validate_attempts, calculate_mastery, rank_lessons, and render_recommendation components. Each can be tested with a tiny deterministic example.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What should an interface specify besides the names of inputs and outputs?

<details>
<summary>Reveal answer</summary>

Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

</details>

### Practice before continuing

- **NAA-01-02-021** Explain Decomposition and interfaces in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-022** Apply Decomposition and interfaces to a plant-image learning project. Name the input, operation, output, and one validation check.
- **NAA-01-02-023** Compare a correct use of Decomposition and interfaces with the misconception below: 'Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.' Explain the consequence of the mistake.
- **NAA-01-02-024** Create a small trace for Decomposition and interfaces in an environmental sensor project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 4. Algorithms and unambiguous steps

### Core explanation

An algorithm is a finite sequence of unambiguous operations that transforms valid input into output. Precision matters because a computer cannot infer unstated intention. Words such as best, nearby, similar, and enough must be defined. Pseudocode should expose decisions, repetition, and state changes without depending on one programming language. A correct algorithm also addresses empty input, invalid values, ties, and termination. Writing pseudocode before code makes logic review possible for people who do not use the implementation language.

### Deep reasoning

To reason well about algorithms and unambiguous steps, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, algorithms and unambiguous steps also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

Instead of 'choose the weakest topic,' define mastery per topic, exclude topics without enough attempts, select the minimum score, and break ties by the oldest review time.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What makes a step such as 'choose a similar example' ambiguous?

<details>
<summary>Reveal answer</summary>

The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

</details>

### Practice before continuing

- **NAA-01-02-031** Explain Algorithms and unambiguous steps in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-032** Apply Algorithms and unambiguous steps to a local library search tool. Name the input, operation, output, and one validation check.
- **NAA-01-02-033** Compare a correct use of Algorithms and unambiguous steps with the misconception below: 'Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.' Explain the consequence of the mistake.
- **NAA-01-02-034** Create a small trace for Algorithms and unambiguous steps in a language-learning application. Show the initial state, two meaningful transformations, the result, and an independent check.

## 5. Tracing state and invariants

### Core explanation

Tracing records the state after each operation for a small input. It reveals off-by-one errors, unexpected mutations, wrong branch order, and invalid assumptions. An invariant is a condition that should remain true at a chosen point, such as processed_count plus remaining_count equals total_count. Loop invariants support correctness reasoning because they connect the state before an iteration, the update, and the state after it. Trace tables should use the exact same variable meanings as the algorithm.

### Deep reasoning

To reason well about tracing state and invariants, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, tracing state and invariants also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

When scanning scores for a maximum, an invariant is that current_best equals the maximum among already processed valid scores. The update preserves it when the next score is compared correctly.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** State an invariant for counting valid records in a list.

<details>
<summary>Reveal answer</summary>

After processing the first k records, valid_count equals the number of valid records among exactly those k records.

</details>

### Practice before continuing

- **NAA-01-02-041** Explain Tracing state and invariants in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-042** Apply Tracing state and invariants to an environmental sensor project. Name the input, operation, output, and one validation check.
- **NAA-01-02-043** Compare a correct use of Tracing state and invariants with the misconception below: 'Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.' Explain the consequence of the mistake.
- **NAA-01-02-044** Create a small trace for Tracing state and invariants in a transport-delay analysis. Show the initial state, two meaningful transformations, the result, and an independent check.

## 6. Boundary cases, errors, and termination

### Core explanation

Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff. Error handling distinguishes invalid input from a valid result such as an empty match set. For iterative algorithms, a termination measure must move toward a stopping condition. A while loop that waits for a value to change can run forever when the update does not affect that value. Boundary tests should be designed from the specification, not added only after a bug appears.

### Deep reasoning

To reason well about boundary cases, errors, and termination, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, boundary cases, errors, and termination also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A normalizer using (x-min)/(max-min) must define behavior when max equals min. Raising a clear error or returning a documented constant are different contracts.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Give three boundary tests for selecting the smallest number.

<details>
<summary>Reveal answer</summary>

An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

</details>

### Practice before continuing

- **NAA-01-02-051** Explain Boundary cases, errors, and termination in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-052** Apply Boundary cases, errors, and termination to a language-learning application. Name the input, operation, output, and one validation check.
- **NAA-01-02-053** Compare a correct use of Boundary cases, errors, and termination with the misconception below: 'Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.' Explain the consequence of the mistake.
- **NAA-01-02-054** Create a small trace for Boundary cases, errors, and termination in a science-fair investigation. Show the initial state, two meaningful transformations, the result, and an independent check.

## 7. Correctness, efficiency, and tradeoffs

### Core explanation

Correctness asks whether the algorithm satisfies its specification for all valid inputs. Efficiency asks how time and memory grow. Maintainability asks whether people can inspect and safely change it. These goals can conflict. A faster method is not an improvement if it changes behavior or makes critical assumptions invisible. Compare algorithms using input size and operations rather than one timing result. Big-O notation describes growth, while measurement captures constants, hardware, and implementation details.

### Deep reasoning

To reason well about correctness, efficiency, and tradeoffs, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, correctness, efficiency, and tradeoffs also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

Finding repeated IDs with nested scans may grow quadratically; storing seen IDs in a set uses extra memory but usually makes expected processing linear.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** When is an O(n log n) algorithm not automatically better than an O(n squared) one?

<details>
<summary>Reveal answer</summary>

For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

</details>

### Practice before continuing

- **NAA-01-02-061** Explain Correctness, efficiency, and tradeoffs in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-062** Apply Correctness, efficiency, and tradeoffs to a transport-delay analysis. Name the input, operation, output, and one validation check.
- **NAA-01-02-063** Compare a correct use of Correctness, efficiency, and tradeoffs with the misconception below: 'Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.' Explain the consequence of the mistake.
- **NAA-01-02-064** Create a small trace for Correctness, efficiency, and tradeoffs in a learner-progress dashboard. Show the initial state, two meaningful transformations, the result, and an independent check.

## 8. Design review and algorithmic evidence

### Core explanation

An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision. Reviewers should be able to challenge assumptions without reading every implementation detail. A small reference implementation can serve as an oracle for testing an optimized version. Versioning the specification matters because changing a threshold or tie rule changes behavior even if the function name remains the same.

### Deep reasoning

To reason well about design review and algorithmic evidence, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, design review and algorithmic evidence also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Problem Decomposition and Algorithms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A search algorithm can be tested against exhaustive search on small graphs. Matching outputs across many generated small cases gives evidence, while separately designed edge cases target known risks.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What should be frozen before comparing two algorithm implementations?

<details>
<summary>Reveal answer</summary>

The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

</details>

### Practice before continuing

- **NAA-01-02-071** Explain Design review and algorithmic evidence in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-02-072** Apply Design review and algorithmic evidence to a science-fair investigation. Name the input, operation, output, and one validation check.
- **NAA-01-02-073** Compare a correct use of Design review and algorithmic evidence with the misconception below: 'Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.' Explain the consequence of the mistake.
- **NAA-01-02-074** Create a small trace for Design review and algorithmic evidence in a small accessibility tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## Lesson synthesis

Use the following four-column method to connect the whole lesson:

| Concept | Mechanism | Evidence | Limitation |
|---|---|---|---|
| From goals to computational problems | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan. |
| Inputs, outputs, constraints, and assumptions | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process. |
| Decomposition and interfaces | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function. |
| Algorithms and unambiguous steps | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation. |
| Tracing state and invariants | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Testing only the final output. Two internal errors can cancel on one example while failing elsewhere. |
| Boundary cases, errors, and termination | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement. |
| Correctness, efficiency, and tradeoffs | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck. |
| Design review and algorithmic evidence | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions. |

## Applied project

Write a complete algorithm design document for an offline next-lesson recommender. Include specification, decomposition diagram, pseudocode, trace table, invariants, edge cases, complexity, baseline, and acceptance tests. Then implement only the smallest deterministic version.

### Required project evidence

- A one-page specification
- A mechanism or component diagram
- One worked example with intermediate states
- One boundary case and one preserved failure
- A baseline or invariant
- A limitations and responsibility statement

## Glossary

- **specification:** A precise statement of inputs, outputs, constraints, assumptions, and required behavior.
- **algorithm:** A finite and unambiguous sequence of operations.
- **decomposition:** Breaking a system into responsibilities with clear interfaces.
- **interface:** The contract through which components exchange data or behavior.
- **pseudocode:** Language-independent structured description of an algorithm.
- **invariant:** A condition that remains true at a defined point in an algorithm.
- **boundary case:** An input at or near the edge of valid behavior.
- **termination:** The guarantee that an algorithm eventually stops.
- **complexity:** How resource use grows with input size.
- **baseline:** A reference method used for comparison.

## Lesson quiz

Complete the quiz without notes. Multiple-choice items are scored automatically; written items use the provided rubric after submission.

1. **NAA-01-02-081** Turn 'make a smart school app' into one testable computational problem.
   - A. Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.
   - B. A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. The newest or most complex method should be selected before defining the task and constraints.
2. **NAA-01-02-082** Why is 'future quiz score' an invalid input for choosing a lesson before the quiz?
   - A. It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.
3. **NAA-01-02-083** What should an interface specify besides the names of inputs and outputs?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.
   - D. Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.
4. **NAA-01-02-084** What makes a step such as 'choose a similar example' ambiguous?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.
5. **NAA-01-02-085** State an invariant for counting valid records in a list.
   - A. Testing only the final output. Two internal errors can cancel on one example while failing elsewhere.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. After processing the first k records, valid_count equals the number of valid records among exactly those k records.
6. **NAA-01-02-086** Give three boundary tests for selecting the smallest number.
   - A. Using a default value that hides invalid data. Returning zero for every parsing error can turn missing information into a real measurement.
   - B. An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
7. **NAA-01-02-087** When is an O(n log n) algorithm not automatically better than an O(n squared) one?
   - A. Optimizing before measuring. Replacing clear code with complex code can introduce defects while improving an operation that was never a bottleneck.
   - B. For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
8. **NAA-01-02-088** What should be frozen before comparing two algorithm implementations?
   - A. The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.
   - B. Calling tests proof of universal correctness. Tests provide evidence for selected cases; a proof requires reasoning that covers every valid input under stated assumptions.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
9. **NAA-01-02-089** Which response best corrects this misconception about From goals to computational problems: 'Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.'?
   - A. A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Beginning with a favorite model. Model choice comes after the task, data, constraints, and evaluation plan.
10. **NAA-01-02-090** Which response best corrects this misconception about Inputs, outputs, constraints, and assumptions: 'Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.'?
   - A. Treating all stored data as available input. Availability depends on time, permission, reliability, and the real deployment process.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.
11. **NAA-01-02-091** Which response best corrects this misconception about Decomposition and interfaces: 'Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.'?
   - A. Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.
12. **NAA-01-02-092** Which response best corrects this misconception about Algorithms and unambiguous steps: 'Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Writing pseudocode that merely restates the goal. 'Analyze the data intelligently' does not define an operation.
13. **NAA-01-02-093** Use a plant-image learning project to explain Tracing state and invariants through a complete input-to-output chain.
14. **NAA-01-02-094** Evaluate a confident product claim about Boundary cases, errors, and termination and rewrite it as a narrow, testable claim.
15. **NAA-01-02-095** Design one boundary test and one failure-regression test for Correctness, efficiency, and tradeoffs.
16. **NAA-01-02-096** Connect Design review and algorithmic evidence to another idea in this lesson and explain why the connection matters.
17. **NAA-01-02-097** Propose an offline mini-project that demonstrates From goals to computational problems with saved evidence.
18. **NAA-01-02-098** Explain what a responsible human reviewer should inspect before accepting a result involving Inputs, outputs, constraints, and assumptions.
19. **NAA-01-02-099** Give a counterexample to the misconception 'Splitting code by line count rather than responsibility. Two short functions with hidden shared state may be harder to reason about than one clear function.' and explain the corrected rule.
20. **NAA-01-02-100** Write a six-sentence mastery explanation of Algorithms and unambiguous steps for a learner who has never studied AI.

## Completion rule

A lesson is complete when the learner reads all eight units, answers each embedded check, submits the notes, masters at least 64 of 80 practice tasks, scores at least 16 of 20 on the quiz or completes corrections, and submits the applied project evidence.
