# Quick Sheet - S01-L02: Problem Decomposition and Algorithms

**Big question:** How can we transform a real goal into small, precise, ordered, and testable steps before writing code?

## Essential ideas

### From goals to computational problems

A real goal such as help learners study better is not yet a computational problem.

**Remember:** A valid answer names a user decision, input, output, constraints, and metric, such as ranking the next three review topics from local attempt history and measuring later quiz improvement.

### Inputs, outputs, constraints, and assumptions

Inputs are the information available at the moment of computation.

**Remember:** It is unavailable at decision time and directly contains information about the outcome, creating temporal and target leakage.

### Decomposition and interfaces

Decomposition breaks a system into responsibilities that can be understood and tested separately.

**Remember:** Types, units or meaning, valid ranges, error behavior, side effects, and invariants that callers may rely on.

### Algorithms and unambiguous steps

An algorithm is a finite sequence of unambiguous operations that transforms valid input into output.

**Remember:** The similarity representation, distance or comparison rule, candidate set, tie handling, and acceptance threshold are unspecified.

### Tracing state and invariants

Tracing records the state after each operation for a small input.

**Remember:** After processing the first k records, valid_count equals the number of valid records among exactly those k records.

### Boundary cases, errors, and termination

Boundary cases sit at the edge of valid behavior: empty collections, one item, equal values, zero ranges, maximum size, and thresholds exactly at a cutoff.

**Remember:** An empty list with defined error behavior, a one-item list, and a list with tied minima; negative and extreme values can be additional tests.

### Correctness, efficiency, and tradeoffs

Correctness asks whether the algorithm satisfies its specification for all valid inputs.

**Remember:** For very small inputs, constants and simplicity can dominate; correctness and maintainability may matter more. Growth rate predicts scaling, not every individual runtime.

### Design review and algorithmic evidence

An algorithm review should include the specification, pseudocode, examples, invariants, boundary tests, complexity, failure handling, and evidence that the output serves the real decision.

**Remember:** The input contract, expected behavior, tie and error rules, test cases, measurement method, and environment relevant to the comparison.

## Universal reasoning checklist

1. Define the task and unit.
2. Separate inputs, operations, outputs, and constraints.
3. Predict before computing.
4. Compare with a baseline or invariant.
5. Test a boundary and preserve failures.
6. State evidence, limitations, and human responsibility.
