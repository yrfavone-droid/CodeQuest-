# Student Notes - S01-L02: Problem Decomposition and Algorithms

Complete these notes from memory before reopening the article.

## Big question

How can we transform a real goal into small, precise, ordered, and testable steps before writing code?

## Retrieval notes

### 1. From goals to computational problems

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Turn 'make a smart school app' into one testable computational problem.

**My answer:**

---

### 2. Inputs, outputs, constraints, and assumptions

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why is 'future quiz score' an invalid input for choosing a lesson before the quiz?

**My answer:**

---

### 3. Decomposition and interfaces

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What should an interface specify besides the names of inputs and outputs?

**My answer:**

---

### 4. Algorithms and unambiguous steps

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What makes a step such as 'choose a similar example' ambiguous?

**My answer:**

---

### 5. Tracing state and invariants

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** State an invariant for counting valid records in a list.

**My answer:**

---

### 6. Boundary cases, errors, and termination

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Give three boundary tests for selecting the smallest number.

**My answer:**

---

### 7. Correctness, efficiency, and tradeoffs

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** When is an O(n log n) algorithm not automatically better than an O(n squared) one?

**My answer:**

---

### 8. Design review and algorithmic evidence

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What should be frozen before comparing two algorithm implementations?

**My answer:**

---

## Final one-page explanation

Explain the entire lesson to a new learner without using unexplained vocabulary. Include one diagram, one worked example, one counterexample, and one honest limitation.
