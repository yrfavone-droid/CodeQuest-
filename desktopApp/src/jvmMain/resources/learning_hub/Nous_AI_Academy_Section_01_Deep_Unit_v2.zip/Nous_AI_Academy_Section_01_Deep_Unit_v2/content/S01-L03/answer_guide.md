# Answer Guide - S01-L03: Data, Features, Labels, Models, and Inference

Rubric answers evaluate reasoning, not exact wording.

## Embedded checks

### 1. Why does the unit of observation affect the train-test split?

Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### 2. Give two distinct features that can be created from a timestamp and explain their different meanings.

Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### 3. Why might 'completed lesson' be a weak label for mastery?

Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### 4. What question should be asked before claiming results generalize to all learners?

Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### 5. Distinguish a parameter, a hyperparameter, and a threshold.

A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### 6. Why is repeated tuning on the test set a form of training?

Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### 7. What should happen when an inference input violates the schema?

The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### 8. Name four items needed to make a performance claim interpretable.

A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

## Practice answers and rubrics

### NAA-01-03-001

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-002

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-003

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-004

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-005

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-006

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-007

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-008

**Answer/rubric:** B

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target. The tempting error is: Assuming rows are independent because they appear on separate lines.

### NAA-01-03-009

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-010

**Answer/rubric:** A complete response must accurately use this reference idea: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It should address the worked-case evidence: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. It must not repeat this misconception: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-011

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-012

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-013

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-014

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-015

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-016

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-017

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-018

**Answer/rubric:** A

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses. The tempting error is: Calling a column a feature without checking whether it is available at prediction time.

### NAA-01-03-019

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-020

**Answer/rubric:** A complete response must accurately use this reference idea: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It should address the worked-case evidence: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. It must not repeat this misconception: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-021

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-022

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-023

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-024

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-025

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-026

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-027

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-028

**Answer/rubric:** A

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance. The tempting error is: Treating labels as unquestionable ground truth.

### NAA-01-03-029

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-030

**Answer/rubric:** A complete response must accurately use this reference idea: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It should address the worked-case evidence: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. It must not repeat this misconception: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-031

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-032

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-033

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-034

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-035

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-036

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-037

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-038

**Answer/rubric:** C

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim. The tempting error is: Assuming a large dataset is automatically representative.

### NAA-01-03-039

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-040

**Answer/rubric:** A complete response must accurately use this reference idea: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It should address the worked-case evidence: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. It must not repeat this misconception: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### NAA-01-03-041

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-042

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-043

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-044

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-045

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-046

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-047

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-048

**Answer/rubric:** A

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class. The tempting error is: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

### NAA-01-03-049

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-050

**Answer/rubric:** A complete response must accurately use this reference idea: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It should address the worked-case evidence: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. It must not repeat this misconception: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-051

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-052

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-053

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-054

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-055

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-056

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-057

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-058

**Answer/rubric:** C

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence. The tempting error is: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

### NAA-01-03-059

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-060

**Answer/rubric:** A complete response must accurately use this reference idea: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It should address the worked-case evidence: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. It must not repeat this misconception: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-061

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-062

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-063

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-064

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-065

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-066

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-067

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-068

**Answer/rubric:** C

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source. The tempting error is: Assuming that successful model loading proves the inference path is correct.

### NAA-01-03-069

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-070

**Answer/rubric:** A complete response must accurately use this reference idea: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It should address the worked-case evidence: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. It must not repeat this misconception: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-071

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-072

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-073

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-074

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-075

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-076

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-077

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-078

**Answer/rubric:** B

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important. The tempting error is: Reporting one average metric as proof that the entire pipeline is reliable.

### NAA-01-03-079

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-080

**Answer/rubric:** A complete response must accurately use this reference idea: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It should address the worked-case evidence: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. It must not repeat this misconception: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

## Quiz answers

### NAA-01-03-081

**Answer/rubric:** C

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target. The tempting error is: Assuming rows are independent because they appear on separate lines.

### NAA-01-03-082

**Answer/rubric:** A

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses. The tempting error is: Calling a column a feature without checking whether it is available at prediction time.

### NAA-01-03-083

**Answer/rubric:** C

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance. The tempting error is: Treating labels as unquestionable ground truth.

### NAA-01-03-084

**Answer/rubric:** C

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim. The tempting error is: Assuming a large dataset is automatically representative.

### NAA-01-03-085

**Answer/rubric:** B

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class. The tempting error is: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

### NAA-01-03-086

**Answer/rubric:** A

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence. The tempting error is: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

### NAA-01-03-087

**Answer/rubric:** A

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source. The tempting error is: Assuming that successful model loading proves the inference path is correct.

### NAA-01-03-088

**Answer/rubric:** B

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important. The tempting error is: Reporting one average metric as proof that the entire pipeline is reliable.

### NAA-01-03-089

**Answer/rubric:** B

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target. The tempting error is: Assuming rows are independent because they appear on separate lines.

### NAA-01-03-090

**Answer/rubric:** C

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses. The tempting error is: Calling a column a feature without checking whether it is available at prediction time.

### NAA-01-03-091

**Answer/rubric:** A

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance. The tempting error is: Treating labels as unquestionable ground truth.

### NAA-01-03-092

**Answer/rubric:** D

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim. The tempting error is: Assuming a large dataset is automatically representative.

### NAA-01-03-093

**Answer/rubric:** The response must accurately use: A model maps features to outputs using a structure and parameters. Training adjusts parameters to reduce an objective on training data. The objective is a mathematical stand-in for the product goal, so its definition matters. Two models trained on the same records can behave differently because of loss, regularization, architecture, class weighting, or thresholds. Hyperparameters control training or structure and are selected through validation rather than directly fitted in the same way as ordinary parameters. It must include evidence consistent with: A logistic model learns weights and a bias. A decision threshold is often selected afterward based on error costs. The learned score and the final class are related but separate. and correct: Saying the model decided its own purpose. People choose the data, target, objective, constraints, and deployment policy.

**Explanation:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### NAA-01-03-094

**Answer/rubric:** The response must accurately use: Training data fits parameters. Validation data guides model, hyperparameter, or threshold choices. Test data is reserved for a final estimate after choices stop. Leakage occurs when information unavailable in real use influences fitting or selection. It can enter through target-derived features, future timestamps, preprocessing fitted on all data, duplicates across splits, or repeated test inspection. A pipeline should fit every learned transformation within training folds. The test set cannot remain an honest test if it becomes a repeated development dashboard. It must include evidence consistent with: Computing normalization statistics before splitting lets held-out values influence training. Fitting the scaler on training data and applying it to validation/test prevents that path. and correct: Thinking leakage requires the label column to be copied directly. Indirect future or group information can leak just as strongly.

**Explanation:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### NAA-01-03-095

**Answer/rubric:** The response must accurately use: Inference is the complete path from a new input to an output, not just one model call. It includes schema validation, missing-value handling, transformations, model execution, post-processing, thresholding, error handling, and logging allowed by privacy rules. Training and inference must share the same feature definitions. A data contract states required fields, types, ranges, version, and failure behavior. Silent coercion is risky: turning an invalid category into zero may produce a confident-looking prediction. It must include evidence consistent with: A local app can reject a score outside 0 to 1, apply the saved training scaler, load a versioned model, return a score and explanation metadata, and record only non-sensitive diagnostics. and correct: Assuming that successful model loading proves the inference path is correct.

**Explanation:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### NAA-01-03-096

**Answer/rubric:** The response must accurately use: A prediction is useful only inside an evaluated decision process. Metrics should reflect error costs and be reported with baselines, sample sizes, uncertainty, subgroup or condition checks, and failure examples. Data cards document collection and limitations; model cards document intended use, evaluation, limitations, and oversight. Version links connect the exact data, code, configuration, model, and report. Documentation is not decoration. It is part of the interface through which future developers and users understand the system's valid scope. It must include evidence consistent with: A model card for a lesson recommender can state it supports ranking practice, does not diagnose ability, uses local attempt history, was evaluated on defined pilot data, and permits full override. and correct: Reporting one average metric as proof that the entire pipeline is reliable.

**Explanation:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

### NAA-01-03-097

**Answer/rubric:** The response must accurately use: A dataset is not merely a file. Each row or item represents a unit of observation, and every variable has a meaning tied to how and when it was measured. Before modeling, state whether one row represents a learner, attempt, session, image, day, or event. Mixed units create false patterns: treating repeated attempts as independent learners changes sample size and can leak identity across splits. A data dictionary records field definitions, types, units, valid ranges, collection times, and missing-value meanings. It must include evidence consistent with: If each learner contributes twenty attempts, random row splitting can place attempts from the same learner in training and test sets. A group split by learner better evaluates performance on unseen learners. and correct: Assuming rows are independent because they appear on separate lines.

**Explanation:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### NAA-01-03-098

**Answer/rubric:** The response must accurately use: Raw data is the information collected before model-specific transformation. Features are numerical or categorical representations supplied to a model. Feature engineering may aggregate, encode, scale, or extract information. The representation determines which patterns are easy for a model to learn and which information is discarded. A timestamp can become hour of day, time since last attempt, or sequence position; these features answer different questions. Every transformation should be fitted only with permitted training information and applied identically during inference. It must include evidence consistent with: A text classifier may transform documents into token counts or embeddings. A count representation ignores much word order, while an embedding preserves other learned relationships but introduces dependence on its training source. and correct: Calling a column a feature without checking whether it is available at prediction time.

**Explanation:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### NAA-01-03-099

**Answer/rubric:** The response must accurately use: A label is the target used for supervised training, but it is often a proxy for the real goal. Label quality depends on definition, measurement, annotator agreement, and timing. A convenient label can reward the wrong behavior. For example, lesson completion may measure clicks rather than understanding. Noisy labels limit attainable performance and can create systematic bias when errors differ across groups. Label guidelines, uncertain categories, adjudication, and inter-rater checks help quantify the problem. It must include evidence consistent with: A helpful-response dataset can let reviewers mark helpful, not helpful, or uncertain, record reasons, and resolve disagreements. Collapsing uncertainty too early hides information. and correct: Treating labels as unquestionable ground truth.

**Explanation:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### NAA-01-03-100

**Answer/rubric:** The response must accurately use: A sample contains observed cases; the population is the broader set about which the team wants to make claims. Selection determines whose behavior appears in the sample. Voluntary users, one device type, one school, or one language may not represent future users. More rows do not repair systematic selection bias. Data provenance should document source, time range, permissions, exclusions, and known gaps. Evaluation should reproduce important deployment conditions or clearly limit the claim. It must include evidence consistent with: A model trained on learners who finish optional practice may overestimate performance for learners who stop early because the sample excludes difficult disengagement cases. and correct: Assuming a large dataset is automatically representative.

**Explanation:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.
