# Quick Sheet - S01-L03: Data, Features, Labels, Models, and Inference

**Big question:** How does raw information become a model output, and where can meaning or reliability be lost along that path?

## Essential ideas

### Observations, variables, and the unit of analysis

A dataset is not merely a file.

**Remember:** Related rows from the same underlying unit can share information. They often need to remain together to prevent leakage and to match the intended generalization target.

### Raw data, features, and representations

Raw data is the information collected before model-specific transformation.

**Remember:** Hour of day represents a daily position; elapsed time since a previous event represents spacing or delay. They support different hypotheses.

### Labels, targets, and measurement quality

A label is the target used for supervised training, but it is often a proxy for the real goal.

**Remember:** Completion can occur without understanding and can be affected by interface behavior. A better target needs evidence such as later independent performance.

### Samples, populations, and selection

A sample contains observed cases; the population is the broader set about which the team wants to make claims.

**Remember:** Whether the sample and evaluation conditions represent the target learners, time periods, devices, languages, and usage patterns relevant to the claim.

### Models, parameters, and objectives

A model maps features to outputs using a structure and parameters.

**Remember:** A parameter is fitted from training data; a hyperparameter configures the model or fitting process and is chosen with validation; a threshold converts a score into an action or class.

### Training, validation, testing, and leakage

Training data fits parameters.

**Remember:** Choices begin adapting to test-specific noise, so test results no longer estimate performance on unseen evidence.

### Inference pipelines and data contracts

Inference is the complete path from a new input to an output, not just one model call.

**Remember:** The system should return a clear structured error or documented fallback, avoid producing a misleading normal prediction, and preserve enough safe diagnostic evidence to fix the source.

### From prediction to evidence and documentation

A prediction is useful only inside an evaluated decision process.

**Remember:** A defined evaluation set, baseline, metric with sample size or uncertainty, and operating conditions or subgroup results; failure examples and threshold are also important.

## Universal reasoning checklist

1. Define the task and unit.
2. Separate inputs, operations, outputs, and constraints.
3. Predict before computing.
4. Compare with a baseline or invariant.
5. Test a boundary and preserve failures.
6. State evidence, limitations, and human responsibility.
