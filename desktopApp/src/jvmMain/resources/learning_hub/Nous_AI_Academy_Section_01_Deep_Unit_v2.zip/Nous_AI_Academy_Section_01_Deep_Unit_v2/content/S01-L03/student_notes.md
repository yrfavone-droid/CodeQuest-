# Student Notes - S01-L03: Data, Features, Labels, Models, and Inference

Complete these notes from memory before reopening the article.

## Big question

How does raw information become a model output, and where can meaning or reliability be lost along that path?

## Retrieval notes

### 1. Observations, variables, and the unit of analysis

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why does the unit of observation affect the train-test split?

**My answer:**

---

### 2. Raw data, features, and representations

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Give two distinct features that can be created from a timestamp and explain their different meanings.

**My answer:**

---

### 3. Labels, targets, and measurement quality

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why might 'completed lesson' be a weak label for mastery?

**My answer:**

---

### 4. Samples, populations, and selection

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What question should be asked before claiming results generalize to all learners?

**My answer:**

---

### 5. Models, parameters, and objectives

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Distinguish a parameter, a hyperparameter, and a threshold.

**My answer:**

---

### 6. Training, validation, testing, and leakage

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why is repeated tuning on the test set a form of training?

**My answer:**

---

### 7. Inference pipelines and data contracts

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What should happen when an inference input violates the schema?

**My answer:**

---

### 8. From prediction to evidence and documentation

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Name four items needed to make a performance claim interpretable.

**My answer:**

---

## Final one-page explanation

Explain the entire lesson to a new learner without using unexplained vocabulary. Include one diagram, one worked example, one counterexample, and one honest limitation.
