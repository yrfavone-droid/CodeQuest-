# Answer Guide - S01-L04: Learning Paradigms

Rubric answers evaluate reasoning, not exact wording.

## Embedded checks

### 1. What single question most directly identifies a learning paradigm?

What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### 2. Why inspect errors even after strong held-out accuracy?

Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### 3. Why can scaling change k-means clusters?

Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### 4. What is the target in masked-token training?

The original hidden token, created automatically from the input text by masking part of it.

### 5. Why keep a clean human-reviewed validation set?

It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### 6. What makes reinforcement learning different from ordinary supervised prediction?

Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### 7. Why should each learned component have its own evaluation?

Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### 8. What evidence should justify moving from a rule to reinforcement learning?

A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

## Practice answers and rubrics

### NAA-01-04-001

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-002

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-003

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-004

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-005

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-006

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-007

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-008

**Answer/rubric:** D

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained? The tempting error is: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

### NAA-01-04-009

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-010

**Answer/rubric:** A complete response must accurately use this reference idea: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It should address the worked-case evidence: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. It must not repeat this misconception: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-011

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-012

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-013

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-014

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-015

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-016

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-017

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-018

**Answer/rubric:** C

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types. The tempting error is: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

### NAA-01-04-019

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-020

**Answer/rubric:** A complete response must accurately use this reference idea: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It should address the worked-case evidence: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. It must not repeat this misconception: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-021

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-022

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-023

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-024

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-025

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-026

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-027

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-028

**Answer/rubric:** D

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments. The tempting error is: Treating discovered clusters as natural truths.

### NAA-01-04-029

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-030

**Answer/rubric:** A complete response must accurately use this reference idea: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It should address the worked-case evidence: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. It must not repeat this misconception: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-031

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-032

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-033

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-034

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-035

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-036

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-037

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-038

**Answer/rubric:** A

**Explanation:** The original hidden token, created automatically from the input text by masking part of it. The tempting error is: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

### NAA-01-04-039

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-040

**Answer/rubric:** A complete response must accurately use this reference idea: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It should address the worked-case evidence: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. It must not repeat this misconception: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.

### NAA-01-04-041

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-042

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-043

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-044

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-045

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-046

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-047

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-048

**Answer/rubric:** C

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods. The tempting error is: Evaluating on pseudo-labels created by the same model.

### NAA-01-04-049

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-050

**Answer/rubric:** A complete response must accurately use this reference idea: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It should address the worked-case evidence: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. It must not repeat this misconception: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-051

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-052

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-053

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-054

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-055

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-056

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-057

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-058

**Answer/rubric:** C

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy. The tempting error is: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

### NAA-01-04-059

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-060

**Answer/rubric:** A complete response must accurately use this reference idea: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It should address the worked-case evidence: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. It must not repeat this misconception: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-061

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-062

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-063

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-064

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-065

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-066

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-067

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-068

**Answer/rubric:** A

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects. The tempting error is: Assigning one paradigm to the entire product when components learn differently.

### NAA-01-04-069

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-070

**Answer/rubric:** A complete response must accurately use this reference idea: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It should address the worked-case evidence: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. It must not repeat this misconception: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-071

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-072

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-073

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-074

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-075

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-076

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-077

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-078

**Answer/rubric:** B

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions. The tempting error is: Choosing the newest paradigm instead of the smallest method that answers the question.

### NAA-01-04-079

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-080

**Answer/rubric:** A complete response must accurately use this reference idea: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It should address the worked-case evidence: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. It must not repeat this misconception: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

## Quiz answers

### NAA-01-04-081

**Answer/rubric:** A

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained? The tempting error is: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

### NAA-01-04-082

**Answer/rubric:** D

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types. The tempting error is: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

### NAA-01-04-083

**Answer/rubric:** D

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments. The tempting error is: Treating discovered clusters as natural truths.

### NAA-01-04-084

**Answer/rubric:** C

**Explanation:** The original hidden token, created automatically from the input text by masking part of it. The tempting error is: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

### NAA-01-04-085

**Answer/rubric:** D

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods. The tempting error is: Evaluating on pseudo-labels created by the same model.

### NAA-01-04-086

**Answer/rubric:** B

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy. The tempting error is: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

### NAA-01-04-087

**Answer/rubric:** A

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects. The tempting error is: Assigning one paradigm to the entire product when components learn differently.

### NAA-01-04-088

**Answer/rubric:** D

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions. The tempting error is: Choosing the newest paradigm instead of the smallest method that answers the question.

### NAA-01-04-089

**Answer/rubric:** B

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained? The tempting error is: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

### NAA-01-04-090

**Answer/rubric:** D

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types. The tempting error is: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

### NAA-01-04-091

**Answer/rubric:** D

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments. The tempting error is: Treating discovered clusters as natural truths.

### NAA-01-04-092

**Answer/rubric:** A

**Explanation:** The original hidden token, created automatically from the input text by masking part of it. The tempting error is: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

### NAA-01-04-093

**Answer/rubric:** The response must accurately use: Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them. It must include evidence consistent with: A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set. and correct: Evaluating on pseudo-labels created by the same model.

**Explanation:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### NAA-01-04-094

**Answer/rubric:** The response must accurately use: Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly. It must include evidence consistent with: A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction. and correct: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

**Explanation:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### NAA-01-04-095

**Answer/rubric:** The response must accurately use: Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear. It must include evidence consistent with: A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning. and correct: Assigning one paradigm to the entire product when components learn differently.

**Explanation:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### NAA-01-04-096

**Answer/rubric:** The response must accurately use: Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training. It must include evidence consistent with: For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit. and correct: Choosing the newest paradigm instead of the smallest method that answers the question.

**Explanation:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

### NAA-01-04-097

**Answer/rubric:** The response must accurately use: A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance. It must include evidence consistent with: An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision. and correct: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

**Explanation:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### NAA-01-04-098

**Answer/rubric:** The response must accurately use: Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential. It must include evidence consistent with: A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape. and correct: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

**Explanation:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### NAA-01-04-099

**Answer/rubric:** The response must accurately use: Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review. It must include evidence consistent with: Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation. and correct: Treating discovered clusters as natural truths.

**Explanation:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### NAA-01-04-100

**Answer/rubric:** The response must accurately use: Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task. It must include evidence consistent with: An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset. and correct: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

**Explanation:** The original hidden token, created automatically from the input text by masking part of it.
