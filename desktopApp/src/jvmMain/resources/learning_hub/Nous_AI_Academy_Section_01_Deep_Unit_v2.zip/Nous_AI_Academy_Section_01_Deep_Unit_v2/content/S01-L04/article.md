# S01-L04: Learning Paradigms

## Choose the learning setup that matches the evidence and interaction

**Academy:** Nous AI Academy  
**Format:** Deep Article Lesson  
**Estimated study time:** 3-5 hours across multiple sessions  
**Offline:** Fully supported

## Big question

What information teaches the system, and which learning paradigm fits that source of feedback?

## Learning objectives

- Compare supervised, unsupervised, self-supervised, semi-supervised, and reinforcement learning.
- Identify examples, targets, structure, rewards, and interaction in problem statements.
- Explain when multiple paradigms appear in one system.
- Choose evaluation methods appropriate to each paradigm.
- Reject misleading claims that one paradigm removes the need for assumptions or evidence.

## How to study this lesson

Read one article unit at a time. Before revealing each check answer, write your prediction. Reproduce the worked case, change one condition, and explain what changes. After the article, complete the notes from memory, then use the practice bank. Attempt the lesson quiz only after reaching at least 80% mastery on the selected practice set.

The goal is not to memorize vocabulary. The goal is to trace mechanisms, test claims, identify assumptions, and produce evidence another learner can inspect.

## 1. A paradigm describes the learning signal

### Core explanation

A learning paradigm is defined by the information available for improving behavior. The same model architecture can sometimes be trained under different paradigms. Ask what the examples are, what feedback is supplied, and when that feedback arrives. Supervised learning uses target labels. Unsupervised learning seeks structure without a task label. Self-supervised learning creates targets from the data. Reinforcement learning uses rewards from sequential interaction. Paradigm labels help organize assumptions; they do not guarantee performance.

### Deep reasoning

To reason well about a paradigm describes the learning signal, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, a paradigm describes the learning signal also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

An encoder may first learn from masked text through self-supervision, then be fine-tuned on labeled sentiment examples through supervision.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What single question most directly identifies a learning paradigm?

<details>
<summary>Reveal answer</summary>

What signal or feedback is used to improve the model or policy, and how is that signal obtained?

</details>

### Practice before continuing

- **NAA-01-04-001** Explain A paradigm describes the learning signal in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-002** Apply A paradigm describes the learning signal to an offline study assistant. Name the input, operation, output, and one validation check.
- **NAA-01-04-003** Compare a correct use of A paradigm describes the learning signal with the misconception below: 'Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.' Explain the consequence of the mistake.
- **NAA-01-04-004** Create a small trace for A paradigm describes the learning signal in a plant-image learning project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 2. Supervised learning

### Core explanation

Supervised learning uses paired inputs and targets to learn a mapping. Classification predicts categories; regression predicts continuous values; ranking orders candidates. Labels can come from measurements, human annotation, historical decisions, or later outcomes. Each source introduces possible noise and bias. Evaluation requires held-out labeled data that represents the intended use. A high score can reflect leakage or easy shortcuts, so error analysis and baselines remain essential.

### Deep reasoning

To reason well about supervised learning, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, supervised learning also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A plant classifier learns from images paired with species labels. If background color differs by collection site, the model may learn site rather than plant shape.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why inspect errors even after strong held-out accuracy?

<details>
<summary>Reveal answer</summary>

Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

</details>

### Practice before continuing

- **NAA-01-04-011** Explain Supervised learning in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-012** Apply Supervised learning to a school resource planner. Name the input, operation, output, and one validation check.
- **NAA-01-04-013** Compare a correct use of Supervised learning with the misconception below: 'Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.' Explain the consequence of the mistake.
- **NAA-01-04-014** Create a small trace for Supervised learning in a local library search tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## 3. Unsupervised learning

### Core explanation

Unsupervised learning analyzes inputs without a task label. Clustering groups examples under a similarity rule; dimensionality reduction finds compact representations; anomaly detection identifies unusual patterns. Results depend strongly on representation, distance, scaling, parameters, and the chosen notion of structure. A cluster is not automatically a real category. Evaluation combines internal measures, stability across reasonable choices, usefulness for a stated goal, and domain review.

### Deep reasoning

To reason well about unsupervised learning, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, unsupervised learning also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

Grouping learners by activity patterns may reveal clusters, but naming one 'weak learners' would be unjustified unless independent evidence supports that interpretation.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Treating discovered clusters as natural truths.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why can scaling change k-means clusters?

<details>
<summary>Reveal answer</summary>

Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

</details>

### Practice before continuing

- **NAA-01-04-021** Explain Unsupervised learning in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-022** Apply Unsupervised learning to a plant-image learning project. Name the input, operation, output, and one validation check.
- **NAA-01-04-023** Compare a correct use of Unsupervised learning with the misconception below: 'Treating discovered clusters as natural truths.' Explain the consequence of the mistake.
- **NAA-01-04-024** Create a small trace for Unsupervised learning in an environmental sensor project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 4. Self-supervised and representation learning

### Core explanation

Self-supervised learning constructs prediction tasks from unlabeled data. A text model may predict masked or next tokens; an image model may compare transformed views or reconstruct missing regions. The task creates supervision without manual labels and can produce reusable representations. The pretraining objective still shapes what is learned, and the data source still shapes bias. Downstream evaluation is needed because success on the pretraining task does not guarantee usefulness or fairness for a new task.

### Deep reasoning

To reason well about self-supervised and representation learning, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, self-supervised and representation learning also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

An encoder pretrained to predict missing text can later support classification with a smaller labeled dataset.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What is the target in masked-token training?

<details>
<summary>Reveal answer</summary>

The original hidden token, created automatically from the input text by masking part of it.

</details>

### Practice before continuing

- **NAA-01-04-031** Explain Self-supervised and representation learning in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-032** Apply Self-supervised and representation learning to a local library search tool. Name the input, operation, output, and one validation check.
- **NAA-01-04-033** Compare a correct use of Self-supervised and representation learning with the misconception below: 'Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.' Explain the consequence of the mistake.
- **NAA-01-04-034** Create a small trace for Self-supervised and representation learning in a language-learning application. Show the initial state, two meaningful transformations, the result, and an independent check.

## 5. Semi-supervised and weak supervision

### Core explanation

Semi-supervised learning combines a small labeled set with a larger unlabeled set. Weak supervision uses imperfect rules, heuristics, external models, or noisy sources to create training signals. These approaches can reduce labeling cost but may amplify systematic mistakes. Confidence thresholds, consistency checks, agreement analysis, and clean validation labels help control risk. Pseudo-labels should not be treated as independent ground truth because they inherit errors from the model that created them.

### Deep reasoning

To reason well about semi-supervised and weak supervision, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, semi-supervised and weak supervision also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A classifier trained on 500 reviewed examples can label 5,000 additional examples, retain only high-confidence predictions, and retrain. Improvement must be measured on an untouched reviewed set.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Evaluating on pseudo-labels created by the same model.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why keep a clean human-reviewed validation set?

<details>
<summary>Reveal answer</summary>

It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

</details>

### Practice before continuing

- **NAA-01-04-041** Explain Semi-supervised and weak supervision in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-042** Apply Semi-supervised and weak supervision to an environmental sensor project. Name the input, operation, output, and one validation check.
- **NAA-01-04-043** Compare a correct use of Semi-supervised and weak supervision with the misconception below: 'Evaluating on pseudo-labels created by the same model.' Explain the consequence of the mistake.
- **NAA-01-04-044** Create a small trace for Semi-supervised and weak supervision in a transport-delay analysis. Show the initial state, two meaningful transformations, the result, and an independent check.

## 6. Reinforcement learning

### Core explanation

Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward. Feedback can be delayed, and actions affect later states. A policy selects actions; a value estimates future return. Exploration gathers information while exploitation uses current knowledge. Reward design is central because an agent optimizes the specified signal, which may not match the designer's intention. Simulators and safety constraints are important when real-world exploration is costly.

### Deep reasoning

To reason well about reinforcement learning, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, reinforcement learning also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A practice scheduler receives reward from later mastery, not immediate clicks, because click count could encourage shallow interaction.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What makes reinforcement learning different from ordinary supervised prediction?

<details>
<summary>Reveal answer</summary>

Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

</details>

### Practice before continuing

- **NAA-01-04-051** Explain Reinforcement learning in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-052** Apply Reinforcement learning to a language-learning application. Name the input, operation, output, and one validation check.
- **NAA-01-04-053** Compare a correct use of Reinforcement learning with the misconception below: 'Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.' Explain the consequence of the mistake.
- **NAA-01-04-054** Create a small trace for Reinforcement learning in a science-fair investigation. Show the initial state, two meaningful transformations, the result, and an independent check.

## 7. Hybrid systems and transfer

### Core explanation

Real products often combine paradigms. A representation can be self-supervised, a classifier supervised, a policy fine-tuned from preference rewards, and retrieval unsupervised by vector similarity. Transfer learning reuses knowledge from a source task or dataset. A component diagram should label the paradigm and data source of each stage. This prevents one impressive term from obscuring the actual evidence and makes update responsibilities clear.

### Deep reasoning

To reason well about hybrid systems and transfer, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, hybrid systems and transfer also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A tutor can use self-supervised text embeddings, supervised question-topic labels, unsupervised clustering for exploration, and rule-based safety constraints without using reinforcement learning.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Assigning one paradigm to the entire product when components learn differently.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why should each learned component have its own evaluation?

<details>
<summary>Reveal answer</summary>

Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

</details>

### Practice before continuing

- **NAA-01-04-061** Explain Hybrid systems and transfer in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-062** Apply Hybrid systems and transfer to a transport-delay analysis. Name the input, operation, output, and one validation check.
- **NAA-01-04-063** Compare a correct use of Hybrid systems and transfer with the misconception below: 'Assigning one paradigm to the entire product when components learn differently.' Explain the consequence of the mistake.
- **NAA-01-04-064** Create a small trace for Hybrid systems and transfer in a learner-progress dashboard. Show the initial state, two meaningful transformations, the result, and an independent check.

## 8. Choosing and evaluating a paradigm

### Core explanation

Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility. If reliable labels directly express the goal, supervised learning may be appropriate. If the task is exploration, unsupervised methods can support hypotheses. If unlabeled scale is large, self-supervised pretraining may help. Reinforcement learning is justified only when sequential actions and delayed rewards matter enough to warrant its complexity. Always compare with simpler rules or baselines and define evidence before training.

### Deep reasoning

To reason well about choosing and evaluating a paradigm, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, choosing and evaluating a paradigm also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Learning Paradigms, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

For ordering five fixed lessons from existing mastery scores, a deterministic rule may be enough. Introducing reinforcement learning would add exploration and reward risks without clear benefit.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Choosing the newest paradigm instead of the smallest method that answers the question.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What evidence should justify moving from a rule to reinforcement learning?

<details>
<summary>Reveal answer</summary>

A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

</details>

### Practice before continuing

- **NAA-01-04-071** Explain Choosing and evaluating a paradigm in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-04-072** Apply Choosing and evaluating a paradigm to a science-fair investigation. Name the input, operation, output, and one validation check.
- **NAA-01-04-073** Compare a correct use of Choosing and evaluating a paradigm with the misconception below: 'Choosing the newest paradigm instead of the smallest method that answers the question.' Explain the consequence of the mistake.
- **NAA-01-04-074** Create a small trace for Choosing and evaluating a paradigm in a small accessibility tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## Lesson synthesis

Use the following four-column method to connect the whole lesson:

| Concept | Mechanism | Evidence | Limitation |
|---|---|---|---|
| A paradigm describes the learning signal | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture. |
| Supervised learning | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality. |
| Unsupervised learning | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Treating discovered clusters as natural truths. |
| Self-supervised and representation learning | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation. |
| Semi-supervised and weak supervision | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Evaluating on pseudo-labels created by the same model. |
| Reinforcement learning | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning. |
| Hybrid systems and transfer | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Assigning one paradigm to the entire product when components learn differently. |
| Choosing and evaluating a paradigm | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Choosing the newest paradigm instead of the smallest method that answers the question. |

## Applied project

Analyze one AI product as a hybrid learning system. For each component, state its paradigm, training signal, data source, output, evaluation, and failure modes. Propose the smallest baseline for every learned component.

### Required project evidence

- A one-page specification
- A mechanism or component diagram
- One worked example with intermediate states
- One boundary case and one preserved failure
- A baseline or invariant
- A limitations and responsibility statement

## Glossary

- **supervised learning:** Learning from paired inputs and targets.
- **unsupervised learning:** Seeking structure in inputs without a task label.
- **self-supervised learning:** Creating prediction targets from the data itself.
- **semi-supervised learning:** Combining limited labeled data with larger unlabeled data.
- **weak supervision:** Learning from noisy or indirect labeling sources.
- **reinforcement learning:** Learning actions from rewards in sequential interaction.
- **policy:** A rule or model for selecting actions in states.
- **reward:** A feedback signal used to define reinforcement-learning return.
- **representation:** A transformed encoding of information used by later computation.
- **transfer learning:** Reusing knowledge learned from another task or dataset.

## Lesson quiz

Complete the quiz without notes. Multiple-choice items are scored automatically; written items use the provided rubric after submission.

1. **NAA-01-04-081** What single question most directly identifies a learning paradigm?
   - A. What signal or feedback is used to improve the model or policy, and how is that signal obtained?
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.
2. **NAA-01-04-082** Why inspect errors even after strong held-out accuracy?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.
   - D. Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.
3. **NAA-01-04-083** Why can scaling change k-means clusters?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Treating discovered clusters as natural truths.
   - D. Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.
4. **NAA-01-04-084** What is the target in masked-token training?
   - A. Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The original hidden token, created automatically from the input text by masking part of it.
   - D. The newest or most complex method should be selected before defining the task and constraints.
5. **NAA-01-04-085** Why keep a clean human-reviewed validation set?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. Evaluating on pseudo-labels created by the same model.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.
6. **NAA-01-04-086** What makes reinforcement learning different from ordinary supervised prediction?
   - A. Treating every recommendation system as reinforcement learning. Many recommenders are trained from fixed labeled or ranking data without online sequential learning.
   - B. Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
7. **NAA-01-04-087** Why should each learned component have its own evaluation?
   - A. Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. Assigning one paradigm to the entire product when components learn differently.
   - D. The newest or most complex method should be selected before defining the task and constraints.
8. **NAA-01-04-088** What evidence should justify moving from a rule to reinforcement learning?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Choosing the newest paradigm instead of the smallest method that answers the question.
   - D. A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.
9. **NAA-01-04-089** Which response best corrects this misconception about A paradigm describes the learning signal: 'Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.'?
   - A. Classifying a system only from its output. A text output does not reveal whether the model was trained with labels, self-supervision, reinforcement signals, or a mixture.
   - B. What signal or feedback is used to improve the model or policy, and how is that signal obtained?
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
10. **NAA-01-04-090** Which response best corrects this misconception about Supervised learning: 'Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.'?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Believing supervised means objectively correct. Supervision refers to the presence of targets, not their quality.
   - D. Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.
11. **NAA-01-04-091** Which response best corrects this misconception about Unsupervised learning: 'Treating discovered clusters as natural truths.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. Treating discovered clusters as natural truths.
   - D. Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.
12. **NAA-01-04-092** Which response best corrects this misconception about Self-supervised and representation learning: 'Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.'?
   - A. The original hidden token, created automatically from the input text by masking part of it.
   - B. Saying self-supervised means the system teaches itself without human choices. People choose data, objective, architecture, filtering, and evaluation.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. The newest or most complex method should be selected before defining the task and constraints.
13. **NAA-01-04-093** Use a plant-image learning project to explain Semi-supervised and weak supervision through a complete input-to-output chain.
14. **NAA-01-04-094** Evaluate a confident product claim about Reinforcement learning and rewrite it as a narrow, testable claim.
15. **NAA-01-04-095** Design one boundary test and one failure-regression test for Hybrid systems and transfer.
16. **NAA-01-04-096** Connect Choosing and evaluating a paradigm to another idea in this lesson and explain why the connection matters.
17. **NAA-01-04-097** Propose an offline mini-project that demonstrates A paradigm describes the learning signal with saved evidence.
18. **NAA-01-04-098** Explain what a responsible human reviewer should inspect before accepting a result involving Supervised learning.
19. **NAA-01-04-099** Give a counterexample to the misconception 'Treating discovered clusters as natural truths.' and explain the corrected rule.
20. **NAA-01-04-100** Write a six-sentence mastery explanation of Self-supervised and representation learning for a learner who has never studied AI.

## Completion rule

A lesson is complete when the learner reads all eight units, answers each embedded check, submits the notes, masters at least 64 of 80 practice tasks, scores at least 16 of 20 on the quiz or completes corrections, and submits the applied project evidence.
