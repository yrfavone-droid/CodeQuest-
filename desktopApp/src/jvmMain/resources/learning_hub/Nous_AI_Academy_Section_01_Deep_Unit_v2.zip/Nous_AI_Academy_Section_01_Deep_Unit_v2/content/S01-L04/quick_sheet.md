# Quick Sheet - S01-L04: Learning Paradigms

**Big question:** What information teaches the system, and which learning paradigm fits that source of feedback?

## Essential ideas

### A paradigm describes the learning signal

A learning paradigm is defined by the information available for improving behavior.

**Remember:** What signal or feedback is used to improve the model or policy, and how is that signal obtained?

### Supervised learning

Supervised learning uses paired inputs and targets to learn a mapping.

**Remember:** Average accuracy can hide systematic failures, shortcut features, rare classes, or costly error types.

### Unsupervised learning

Unsupervised learning analyzes inputs without a task label.

**Remember:** Distance depends on feature magnitude; a large-scale feature can dominate the geometry and therefore the assignments.

### Self-supervised and representation learning

Self-supervised learning constructs prediction tasks from unlabeled data.

**Remember:** The original hidden token, created automatically from the input text by masking part of it.

### Semi-supervised and weak supervision

Semi-supervised learning combines a small labeled set with a larger unlabeled set.

**Remember:** It provides evidence independent of the noisy or model-generated training signals used by semi-supervised methods.

### Reinforcement learning

Reinforcement learning studies agents choosing actions in states to maximize expected cumulative reward.

**Remember:** Actions influence future data and reward, feedback may be delayed, and the objective concerns cumulative return under a policy.

### Hybrid systems and transfer

Real products often combine paradigms.

**Remember:** Each component has a different signal, objective, failure mode, and effect on the final output; end-to-end testing alone may not locate defects.

### Choosing and evaluating a paradigm

Choose a paradigm from the decision, available feedback, label cost, interaction, risk, and evaluation feasibility.

**Remember:** A genuinely sequential decision problem, a defensible reward, safe exploration or simulation, sufficient interaction data, and validated improvement over the rule under relevant conditions.

## Universal reasoning checklist

1. Define the task and unit.
2. Separate inputs, operations, outputs, and constraints.
3. Predict before computing.
4. Compare with a baseline or invariant.
5. Test a boundary and preserve failures.
6. State evidence, limitations, and human responsibility.
