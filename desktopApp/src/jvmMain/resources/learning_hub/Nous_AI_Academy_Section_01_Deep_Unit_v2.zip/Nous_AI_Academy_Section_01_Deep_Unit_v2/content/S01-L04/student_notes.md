# Student Notes - S01-L04: Learning Paradigms

Complete these notes from memory before reopening the article.

## Big question

What information teaches the system, and which learning paradigm fits that source of feedback?

## Retrieval notes

### 1. A paradigm describes the learning signal

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What single question most directly identifies a learning paradigm?

**My answer:**

---

### 2. Supervised learning

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why inspect errors even after strong held-out accuracy?

**My answer:**

---

### 3. Unsupervised learning

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why can scaling change k-means clusters?

**My answer:**

---

### 4. Self-supervised and representation learning

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What is the target in masked-token training?

**My answer:**

---

### 5. Semi-supervised and weak supervision

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why keep a clean human-reviewed validation set?

**My answer:**

---

### 6. Reinforcement learning

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What makes reinforcement learning different from ordinary supervised prediction?

**My answer:**

---

### 7. Hybrid systems and transfer

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why should each learned component have its own evaluation?

**My answer:**

---

### 8. Choosing and evaluating a paradigm

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What evidence should justify moving from a rule to reinforcement learning?

**My answer:**

---

## Final one-page explanation

Explain the entire lesson to a new learner without using unexplained vocabulary. Include one diagram, one worked example, one counterexample, and one honest limitation.
