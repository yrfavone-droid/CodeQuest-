# Answer Guide - S01-L05: Evidence, Reproducibility, and Responsible AI

Rubric answers evaluate reasoning, not exact wording.

## Embedded checks

### 1. What information is missing from the claim 'our model achieved 90%'?

The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### 2. Why is a baseline part of evidence rather than an optional extra?

It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### 3. Name five fields required to reproduce or audit a training run.

Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### 4. What turns an error gallery into an engineering tool?

Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### 5. Why can two reasonable fairness metrics disagree?

They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### 6. Give two privacy benefits and two remaining risks of local-only storage.

Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### 7. What makes human oversight real rather than symbolic?

A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### 8. Why should limitations be connected to release tests?

A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

## Practice answers and rubrics

### NAA-01-05-001

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-002

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-003

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-004

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-005

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-006

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-007

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-008

**Answer/rubric:** A

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use. The tempting error is: Removing context to make a number sound universal.

### NAA-01-05-009

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-010

**Answer/rubric:** A complete response must accurately use this reference idea: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It should address the worked-case evidence: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' It must not repeat this misconception: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-011

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-012

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-013

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-014

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-015

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-016

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-017

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-018

**Answer/rubric:** C

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution. The tempting error is: Choosing the metric after seeing which one looks best.

### NAA-01-05-019

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-020

**Answer/rubric:** A complete response must accurately use this reference idea: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It should address the worked-case evidence: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. It must not repeat this misconception: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-021

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-022

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-023

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-024

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-025

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-026

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-027

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-028

**Answer/rubric:** A

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential. The tempting error is: Naming files model_final and model_final2 instead of recording lineage.

### NAA-01-05-029

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-030

**Answer/rubric:** A complete response must accurately use this reference idea: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It should address the worked-case evidence: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. It must not repeat this misconception: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-031

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-032

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-033

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-034

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-035

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-036

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-037

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-038

**Answer/rubric:** A

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria. The tempting error is: Deleting inconvenient failures from evaluation because they are unusual.

### NAA-01-05-039

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-040

**Answer/rubric:** A complete response must accurately use this reference idea: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It should address the worked-case evidence: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. It must not repeat this misconception: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### NAA-01-05-041

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-042

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-043

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-044

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-045

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-046

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-047

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-048

**Answer/rubric:** C

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another. The tempting error is: Claiming fairness because the model never directly reads a protected attribute.

### NAA-01-05-049

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-050

**Answer/rubric:** A complete response must accurately use this reference idea: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It should address the worked-case evidence: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. It must not repeat this misconception: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-051

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-052

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-053

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-054

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-055

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-056

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-057

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-058

**Answer/rubric:** C

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging. The tempting error is: Assuming offline means private and secure by default.

### NAA-01-05-059

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-060

**Answer/rubric:** A complete response must accurately use this reference idea: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It should address the worked-case evidence: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. It must not repeat this misconception: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-061

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-062

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-063

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-064

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-065

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-066

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-067

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-068

**Answer/rubric:** D

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path. The tempting error is: Using a colorful feature chart as proof that a model is correct or causal.

### NAA-01-05-069

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-070

**Answer/rubric:** A complete response must accurately use this reference idea: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It should address the worked-case evidence: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. It must not repeat this misconception: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-071

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-072

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-073

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-074

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-075

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-076

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-077

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-078

**Answer/rubric:** A

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment. The tempting error is: Treating responsible AI as a final paragraph added after technical work.

### NAA-01-05-079

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-080

**Answer/rubric:** A complete response must accurately use this reference idea: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It should address the worked-case evidence: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. It must not repeat this misconception: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

## Quiz answers

### NAA-01-05-081

**Answer/rubric:** A

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use. The tempting error is: Removing context to make a number sound universal.

### NAA-01-05-082

**Answer/rubric:** D

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution. The tempting error is: Choosing the metric after seeing which one looks best.

### NAA-01-05-083

**Answer/rubric:** B

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential. The tempting error is: Naming files model_final and model_final2 instead of recording lineage.

### NAA-01-05-084

**Answer/rubric:** C

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria. The tempting error is: Deleting inconvenient failures from evaluation because they are unusual.

### NAA-01-05-085

**Answer/rubric:** B

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another. The tempting error is: Claiming fairness because the model never directly reads a protected attribute.

### NAA-01-05-086

**Answer/rubric:** C

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging. The tempting error is: Assuming offline means private and secure by default.

### NAA-01-05-087

**Answer/rubric:** B

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path. The tempting error is: Using a colorful feature chart as proof that a model is correct or causal.

### NAA-01-05-088

**Answer/rubric:** D

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment. The tempting error is: Treating responsible AI as a final paragraph added after technical work.

### NAA-01-05-089

**Answer/rubric:** C

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use. The tempting error is: Removing context to make a number sound universal.

### NAA-01-05-090

**Answer/rubric:** B

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution. The tempting error is: Choosing the metric after seeing which one looks best.

### NAA-01-05-091

**Answer/rubric:** C

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential. The tempting error is: Naming files model_final and model_final2 instead of recording lineage.

### NAA-01-05-092

**Answer/rubric:** C

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria. The tempting error is: Deleting inconvenient failures from evaluation because they are unusual.

### NAA-01-05-093

**Answer/rubric:** The response must accurately use: Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score. It must include evidence consistent with: A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths. and correct: Claiming fairness because the model never directly reads a protected attribute.

**Explanation:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### NAA-01-05-094

**Answer/rubric:** The response must accurately use: Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk. It must include evidence consistent with: An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs. and correct: Assuming offline means private and secure by default.

**Explanation:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### NAA-01-05-095

**Answer/rubric:** The response must accurately use: Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded. It must include evidence consistent with: A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson. and correct: Using a colorful feature chart as proof that a model is correct or causal.

**Explanation:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### NAA-01-05-096

**Answer/rubric:** The response must accurately use: Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change. It must include evidence consistent with: A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested. and correct: Treating responsible AI as a final paragraph added after technical work.

**Explanation:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

### NAA-01-05-097

**Answer/rubric:** The response must accurately use: An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result. It must include evidence consistent with: Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.' and correct: Removing context to make a number sound universal.

**Explanation:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### NAA-01-05-098

**Answer/rubric:** The response must accurately use: A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval. It must include evidence consistent with: A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure. and correct: Choosing the metric after seeing which one looks best.

**Explanation:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### NAA-01-05-099

**Answer/rubric:** The response must accurately use: A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service. It must include evidence consistent with: A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism. and correct: Naming files model_final and model_final2 instead of recording lineage.

**Explanation:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### NAA-01-05-100

**Answer/rubric:** The response must accurately use: Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions. It must include evidence consistent with: If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set. and correct: Deleting inconvenient failures from evaluation because they are unusual.

**Explanation:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.
