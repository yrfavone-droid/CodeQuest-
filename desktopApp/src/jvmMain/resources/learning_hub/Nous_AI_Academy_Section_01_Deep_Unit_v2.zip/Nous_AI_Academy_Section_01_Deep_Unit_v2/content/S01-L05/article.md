# S01-L05: Evidence, Reproducibility, and Responsible AI

## Turn AI results into claims that other people can inspect and trust

**Academy:** Nous AI Academy  
**Format:** Deep Article Lesson  
**Estimated study time:** 3-5 hours across multiple sessions  
**Offline:** Fully supported

## Big question

What evidence, records, safeguards, and human decisions are required before an AI result becomes a responsible product claim?

## Learning objectives

- Frame model performance as a claim supported by defined evidence.
- Build reproducible runs linking data, code, configuration, environment, and results.
- Evaluate baselines, uncertainty, error patterns, and affected groups.
- Apply privacy, fairness, transparency, security, and human-oversight principles.
- Produce data cards, model cards, and release gates for a small AI project.

## How to study this lesson

Read one article unit at a time. Before revealing each check answer, write your prediction. Reproduce the worked case, change one condition, and explain what changes. After the article, complete the notes from memory, then use the practice bank. Attempt the lesson quiz only after reaching at least 80% mastery on the selected practice set.

The goal is not to memorize vocabulary. The goal is to trace mechanisms, test claims, identify assumptions, and produce evidence another learner can inspect.

## 1. Claims, evidence, and scope

### Core explanation

An AI result is a claim, not a fact detached from conditions. A complete claim names the task, population, data period, metric, baseline, threshold, uncertainty, and intended use. Evidence supports only the scope it actually covers. A held-out result from one school and one month cannot establish performance everywhere. Strong claims can be narrow and still valuable. Product teams should write the claim before experimentation so metric selection and data collection answer a real question rather than decorate a preferred result.

### Deep reasoning

To reason well about claims, evidence, and scope, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, claims, evidence, and scope also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

Instead of 'the model is 94% accurate,' write: 'On the locked 1,200-example test set collected under the stated conditions, version 1.2 achieved 94% accuracy versus an 88% majority baseline, with class-specific results in the report.'

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Removing context to make a number sound universal.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What information is missing from the claim 'our model achieved 90%'?

<details>
<summary>Reveal answer</summary>

The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

</details>

### Practice before continuing

- **NAA-01-05-001** Explain Claims, evidence, and scope in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-002** Apply Claims, evidence, and scope to an offline study assistant. Name the input, operation, output, and one validation check.
- **NAA-01-05-003** Compare a correct use of Claims, evidence, and scope with the misconception below: 'Removing context to make a number sound universal.' Explain the consequence of the mistake.
- **NAA-01-05-004** Create a small trace for Claims, evidence, and scope in a plant-image learning project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 2. Baselines, metrics, and uncertainty

### Core explanation

A baseline establishes what happens without the proposed complexity. Metrics encode priorities and can hide tradeoffs. Accuracy weights every example equally; precision and recall focus on positive decisions; calibration compares predicted confidence with observed frequency. Report sample size and variation across seeds, folds, time periods, or bootstrap samples when appropriate. Statistical uncertainty does not capture all uncertainty: biased sampling, label errors, and distribution shift can remain even with a narrow interval.

### Deep reasoning

To reason well about baselines, metrics, and uncertainty, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, baselines, metrics, and uncertainty also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A rare-event classifier can reach 99% accuracy by always predicting negative. Precision, recall, and a no-skill baseline reveal the failure.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Choosing the metric after seeing which one looks best.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why is a baseline part of evidence rather than an optional extra?

<details>
<summary>Reveal answer</summary>

It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

</details>

### Practice before continuing

- **NAA-01-05-011** Explain Baselines, metrics, and uncertainty in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-012** Apply Baselines, metrics, and uncertainty to a school resource planner. Name the input, operation, output, and one validation check.
- **NAA-01-05-013** Compare a correct use of Baselines, metrics, and uncertainty with the misconception below: 'Choosing the metric after seeing which one looks best.' Explain the consequence of the mistake.
- **NAA-01-05-014** Create a small trace for Baselines, metrics, and uncertainty in a local library search tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## 3. Reproducible experiments

### Core explanation

A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report. Deterministic behavior is not always possible, but traceability is. Runs need unique IDs and immutable metadata. Input checksums reveal whether data changed. Dependency versions prevent silent changes in numerical behavior. Re-running should create a new result linked to the same specification rather than overwrite the previous evidence. Local-first systems can store this registry in SQLite or JSON without a paid service.

### Deep reasoning

To reason well about reproducible experiments, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, reproducible experiments also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A run record can contain git commit, dataset checksum, split seed, package versions, hyperparameters, metrics, artifact checksum, start time, and notes about nondeterminism.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Naming files model_final and model_final2 instead of recording lineage.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Name five fields required to reproduce or audit a training run.

<details>
<summary>Reveal answer</summary>

Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

</details>

### Practice before continuing

- **NAA-01-05-021** Explain Reproducible experiments in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-022** Apply Reproducible experiments to a plant-image learning project. Name the input, operation, output, and one validation check.
- **NAA-01-05-023** Compare a correct use of Reproducible experiments with the misconception below: 'Naming files model_final and model_final2 instead of recording lineage.' Explain the consequence of the mistake.
- **NAA-01-05-024** Create a small trace for Reproducible experiments in an environmental sensor project. Show the initial state, two meaningful transformations, the result, and an independent check.

## 4. Error analysis and robustness

### Core explanation

Average metrics describe totals, not mechanisms. Error analysis groups failures by class, source, difficulty, input quality, time, or other relevant conditions and inspects representative examples. Robustness testing changes one factor at a time, such as noise, missing fields, language variety, or device conditions. The goal is not to create an endless test list but to connect plausible failure causes to controls. A preserved failure set becomes a regression suite for later versions.

### Deep reasoning

To reason well about error analysis and robustness, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, error analysis and robustness also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

If a text classifier fails on very short messages, create a slice by length, inspect causes, and require the next version not to regress on the locked short-message set.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Deleting inconvenient failures from evaluation because they are unusual.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What turns an error gallery into an engineering tool?

<details>
<summary>Reveal answer</summary>

Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

</details>

### Practice before continuing

- **NAA-01-05-031** Explain Error analysis and robustness in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-032** Apply Error analysis and robustness to a local library search tool. Name the input, operation, output, and one validation check.
- **NAA-01-05-033** Compare a correct use of Error analysis and robustness with the misconception below: 'Deleting inconvenient failures from evaluation because they are unusual.' Explain the consequence of the mistake.
- **NAA-01-05-034** Create a small trace for Error analysis and robustness in a language-learning application. Show the initial state, two meaningful transformations, the result, and an independent check.

## 5. Fairness and affected groups

### Core explanation

Fairness asks how benefits, errors, access, and decision power are distributed. Different fairness metrics can conflict, especially when base rates differ, so context must guide the choice. Group averages can hide intersectional or rare-case failures, while very small samples create high uncertainty. Removing a sensitive column does not remove proxy information. Fairness work therefore includes stakeholder input, data review, subgroup evaluation where appropriate, process safeguards, appeal, and monitoring, not only one mathematical score.

### Deep reasoning

To reason well about fairness and affected groups, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, fairness and affected groups also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A lesson recommender should avoid turning early low scores into fewer learning opportunities. Learners need access to explanations, override, and recovery paths.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Claiming fairness because the model never directly reads a protected attribute.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why can two reasonable fairness metrics disagree?

<details>
<summary>Reveal answer</summary>

They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

</details>

### Practice before continuing

- **NAA-01-05-041** Explain Fairness and affected groups in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-042** Apply Fairness and affected groups to an environmental sensor project. Name the input, operation, output, and one validation check.
- **NAA-01-05-043** Compare a correct use of Fairness and affected groups with the misconception below: 'Claiming fairness because the model never directly reads a protected attribute.' Explain the consequence of the mistake.
- **NAA-01-05-044** Create a small trace for Fairness and affected groups in a transport-delay analysis. Show the initial state, two meaningful transformations, the result, and an independent check.

## 6. Privacy, security, and data minimization

### Core explanation

Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access. Local storage can reduce network exposure but does not automatically provide security. Files need permissions, sensitive fields need careful handling, backups need protection, and logs must avoid unnecessary personal data. Security also includes validating update packages, dependencies, model files, and untrusted input. Threat modeling asks what assets exist, who could misuse them, and what controls reduce risk.

### Deep reasoning

To reason well about privacy, security, and data minimization, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, privacy, security, and data minimization also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

An offline academy can store mastery locally, separate curriculum from user data, verify signed updates, and avoid placing learner answers inside diagnostic logs.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Assuming offline means private and secure by default.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Give two privacy benefits and two remaining risks of local-only storage.

<details>
<summary>Reveal answer</summary>

Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

</details>

### Practice before continuing

- **NAA-01-05-051** Explain Privacy, security, and data minimization in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-052** Apply Privacy, security, and data minimization to a language-learning application. Name the input, operation, output, and one validation check.
- **NAA-01-05-053** Compare a correct use of Privacy, security, and data minimization with the misconception below: 'Assuming offline means private and secure by default.' Explain the consequence of the mistake.
- **NAA-01-05-054** Create a small trace for Privacy, security, and data minimization in a science-fair investigation. Show the initial state, two meaningful transformations, the result, and an independent check.

## 7. Transparency, explainability, and human oversight

### Core explanation

Transparency communicates intended use, data sources, limitations, and decision flow. Explainability can mean global model behavior, local reasons for one output, examples, uncertainty, or simple rules; the appropriate form depends on the user and decision. An explanation is not useful if it is technically impressive but cannot support action. Human oversight must specify who reviews, what evidence they receive, when review occurs, whether they can override, and how appeals or corrections are recorded.

### Deep reasoning

To reason well about transparency, explainability, and human oversight, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, transparency, explainability, and human oversight also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A tutor can show which recent attempts lowered mastery, the uncertainty caused by limited evidence, and a button to choose another lesson.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Using a colorful feature chart as proof that a model is correct or causal.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** What makes human oversight real rather than symbolic?

<details>
<summary>Reveal answer</summary>

A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

</details>

### Practice before continuing

- **NAA-01-05-061** Explain Transparency, explainability, and human oversight in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-062** Apply Transparency, explainability, and human oversight to a transport-delay analysis. Name the input, operation, output, and one validation check.
- **NAA-01-05-063** Compare a correct use of Transparency, explainability, and human oversight with the misconception below: 'Using a colorful feature chart as proof that a model is correct or causal.' Explain the consequence of the mistake.
- **NAA-01-05-064** Create a small trace for Transparency, explainability, and human oversight in a learner-progress dashboard. Show the initial state, two meaningful transformations, the result, and an independent check.

## 8. Cards, release gates, and continuous responsibility

### Core explanation

Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities. A release gate converts these statements into required checks: schema validation, baseline improvement, slice thresholds, privacy review, security checks, offline behavior, rollback, and human approval. Responsibility continues after release through monitoring, incident handling, versioning, and retirement. A model that was acceptable under one distribution may become unreliable as users, policies, or data change.

### Deep reasoning

To reason well about cards, release gates, and continuous responsibility, separate the description of the mechanism from the evidence that it worked. A mechanism explains the operations that connect an input to an output. Evidence compares observed behavior with an expectation, baseline, invariant, or held-out result. When these are mixed, a learner may describe a successful example as if it proves the method. Instead, state the claim, identify what could make it false, and select a check capable of exposing that failure.

In a real product, cards, release gates, and continuous responsibility also has an interface and a lifecycle. Record who supplies the input, when the input exists, which component transforms it, how invalid data is handled, and who interprets the output. Then ask what changes across versions. A data definition, threshold, prompt, model parameter, or user-interface rule can change behavior even when the feature name stays the same. This is why the Nous AI Academy package stores content IDs and version metadata separately from learner progress.

Use a counterexample to deepen the idea. Begin with the lesson's worked case, change exactly one important condition, and predict whether the conclusion still holds. For Evidence, Reproducibility, and Responsible AI, useful changes include missing information, a different user population, a boundary value, a conflicting objective, or an unavailable human reviewer. If the answer changes, name the assumption that was doing the work. If the answer does not change, explain the invariant that keeps the reasoning valid.

### Worked case

A release checklist can block activation when the package checksum fails, test slices regress, the model card is missing, or rollback has not been tested.

Follow this reasoning sequence:

1. Name the exact task and unit being analyzed.
2. Separate available inputs from unavailable or future information.
3. State the mechanism rather than only the product label.
4. Predict an observable result before accepting the output.
5. Check a boundary or counterexample.
6. Record one limitation and the person responsible for the final decision.

### Common misconception

> Treating responsible AI as a final paragraph added after technical work.

Correct the misconception by returning to the mechanism and the evidence. A fluent description, complex interface, or successful example cannot replace a defined test.

### Stop and check

**Question:** Why should limitations be connected to release tests?

<details>
<summary>Reveal answer</summary>

A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

</details>

### Practice before continuing

- **NAA-01-05-071** Explain Cards, release gates, and continuous responsibility in your own words. Include its mechanism, one assumption, and one limitation.
- **NAA-01-05-072** Apply Cards, release gates, and continuous responsibility to a science-fair investigation. Name the input, operation, output, and one validation check.
- **NAA-01-05-073** Compare a correct use of Cards, release gates, and continuous responsibility with the misconception below: 'Treating responsible AI as a final paragraph added after technical work.' Explain the consequence of the mistake.
- **NAA-01-05-074** Create a small trace for Cards, release gates, and continuous responsibility in a small accessibility tool. Show the initial state, two meaningful transformations, the result, and an independent check.

## Lesson synthesis

Use the following four-column method to connect the whole lesson:

| Concept | Mechanism | Evidence | Limitation |
|---|---|---|---|
| Claims, evidence, and scope | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Removing context to make a number sound universal. |
| Baselines, metrics, and uncertainty | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Choosing the metric after seeing which one looks best. |
| Reproducible experiments | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Naming files model_final and model_final2 instead of recording lineage. |
| Error analysis and robustness | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Deleting inconvenient failures from evaluation because they are unusual. |
| Fairness and affected groups | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Claiming fairness because the model never directly reads a protected attribute. |
| Privacy, security, and data minimization | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Assuming offline means private and secure by default. |
| Transparency, explainability, and human oversight | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Using a colorful feature chart as proof that a model is correct or causal. |
| Cards, release gates, and continuous responsibility | State the input-to-output operations | Use the worked case plus a counterexample | Correct: Treating responsible AI as a final paragraph added after technical work. |

## Applied project

Create a release dossier for the Section 1 capstone: claim sheet, experiment record, baseline table, error analysis, data card, model card, privacy review, fairness questions, human-oversight flow, release checklist, and rollback test. The product must remain fully offline.

### Required project evidence

- A one-page specification
- A mechanism or component diagram
- One worked example with intermediate states
- One boundary case and one preserved failure
- A baseline or invariant
- A limitations and responsibility statement

## Glossary

- **evidence:** Observations or results that support a defined claim under stated conditions.
- **reproducibility:** Ability to trace and repeat a process from recorded artifacts and configuration.
- **baseline:** A simple reference used to judge added value.
- **uncertainty:** Quantified or described limits in what the evidence establishes.
- **robustness:** Performance under relevant changes or disturbances.
- **fairness:** The distribution of benefits, errors, access, and decision power under a defined context.
- **data minimization:** Collecting and retaining only information necessary for a stated purpose.
- **explainability:** Methods for making model behavior or individual outputs understandable for a purpose.
- **model card:** A structured document describing a model's purpose, evaluation, limitations, and responsibilities.
- **release gate:** A required check that must pass before activation.

## Lesson quiz

Complete the quiz without notes. Multiple-choice items are scored automatically; written items use the provided rubric after submission.

1. **NAA-01-05-081** What information is missing from the claim 'our model achieved 90%'?
   - A. The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.
   - B. Removing context to make a number sound universal.
   - C. The newest or most complex method should be selected before defining the task and constraints.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
2. **NAA-01-05-082** Why is a baseline part of evidence rather than an optional extra?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. Choosing the metric after seeing which one looks best.
   - D. It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.
3. **NAA-01-05-083** Name five fields required to reproduce or audit a training run.
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.
   - C. Naming files model_final and model_final2 instead of recording lineage.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
4. **NAA-01-05-084** What turns an error gallery into an engineering tool?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. Deleting inconvenient failures from evaluation because they are unusual.
   - C. Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
5. **NAA-01-05-085** Why can two reasonable fairness metrics disagree?
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.
   - C. Claiming fairness because the model never directly reads a protected attribute.
   - D. The newest or most complex method should be selected before defining the task and constraints.
6. **NAA-01-05-086** Give two privacy benefits and two remaining risks of local-only storage.
   - A. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.
   - D. Assuming offline means private and secure by default.
7. **NAA-01-05-087** What makes human oversight real rather than symbolic?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.
   - C. Using a colorful feature chart as proof that a model is correct or causal.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
8. **NAA-01-05-088** Why should limitations be connected to release tests?
   - A. Treating responsible AI as a final paragraph added after technical work.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.
9. **NAA-01-05-089** Which response best corrects this misconception about Claims, evidence, and scope: 'Removing context to make a number sound universal.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - C. The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.
   - D. Removing context to make a number sound universal.
10. **NAA-01-05-090** Which response best corrects this misconception about Baselines, metrics, and uncertainty: 'Choosing the metric after seeing which one looks best.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.
   - C. The method is correct whenever its output looks plausible, so no separate evidence is needed.
   - D. Choosing the metric after seeing which one looks best.
11. **NAA-01-05-091** Which response best corrects this misconception about Reproducible experiments: 'Naming files model_final and model_final2 instead of recording lineage.'?
   - A. Naming files model_final and model_final2 instead of recording lineage.
   - B. The newest or most complex method should be selected before defining the task and constraints.
   - C. Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
12. **NAA-01-05-092** Which response best corrects this misconception about Error analysis and robustness: 'Deleting inconvenient failures from evaluation because they are unusual.'?
   - A. The newest or most complex method should be selected before defining the task and constraints.
   - B. Deleting inconvenient failures from evaluation because they are unusual.
   - C. Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.
   - D. The method is correct whenever its output looks plausible, so no separate evidence is needed.
13. **NAA-01-05-093** Use a plant-image learning project to explain Fairness and affected groups through a complete input-to-output chain.
14. **NAA-01-05-094** Evaluate a confident product claim about Privacy, security, and data minimization and rewrite it as a narrow, testable claim.
15. **NAA-01-05-095** Design one boundary test and one failure-regression test for Transparency, explainability, and human oversight.
16. **NAA-01-05-096** Connect Cards, release gates, and continuous responsibility to another idea in this lesson and explain why the connection matters.
17. **NAA-01-05-097** Propose an offline mini-project that demonstrates Claims, evidence, and scope with saved evidence.
18. **NAA-01-05-098** Explain what a responsible human reviewer should inspect before accepting a result involving Baselines, metrics, and uncertainty.
19. **NAA-01-05-099** Give a counterexample to the misconception 'Naming files model_final and model_final2 instead of recording lineage.' and explain the corrected rule.
20. **NAA-01-05-100** Write a six-sentence mastery explanation of Error analysis and robustness for a learner who has never studied AI.

## Completion rule

A lesson is complete when the learner reads all eight units, answers each embedded check, submits the notes, masters at least 64 of 80 practice tasks, scores at least 16 of 20 on the quiz or completes corrections, and submits the applied project evidence.
