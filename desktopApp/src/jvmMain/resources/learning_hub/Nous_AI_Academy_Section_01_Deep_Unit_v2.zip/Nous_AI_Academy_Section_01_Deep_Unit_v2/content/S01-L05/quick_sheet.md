# Quick Sheet - S01-L05: Evidence, Reproducibility, and Responsible AI

**Big question:** What evidence, records, safeguards, and human decisions are required before an AI result becomes a responsible product claim?

## Essential ideas

### Claims, evidence, and scope

An AI result is a claim, not a fact detached from conditions.

**Remember:** The metric, dataset and sample size, population and conditions, baseline, threshold or decision rule, uncertainty, model version, and intended use.

### Baselines, metrics, and uncertainty

A baseline establishes what happens without the proposed complexity.

**Remember:** It shows whether the model improves on a simpler existing strategy and prevents impressive-looking metrics from hiding a trivial solution.

### Reproducible experiments

A reproducible experiment links exact data, code revision, environment, random seeds, configuration, model artifact, and evaluation report.

**Remember:** Dataset version/checksum, code revision, environment/dependencies, configuration/hyperparameters including seeds, and output artifact/metrics; split information is also essential.

### Error analysis and robustness

Average metrics describe totals, not mechanisms.

**Remember:** Structured categories, linked causes or hypotheses, reproducible inputs, expected behavior, and regression tests tied to release criteria.

### Fairness and affected groups

Fairness asks how benefits, errors, access, and decision power are distributed.

**Remember:** They formalize different goals, and when group prevalence or error tradeoffs differ, satisfying one condition can mathematically prevent satisfying another.

### Privacy, security, and data minimization

Privacy begins by collecting only information needed for a defined purpose, keeping it for a justified period, and controlling access.

**Remember:** Benefits include reduced third-party transfer and user control. Risks include device access, malware, insecure backups, weak permissions, and accidental logging.

### Transparency, explainability, and human oversight

Transparency communicates intended use, data sources, limitations, and decision flow.

**Remember:** A defined responsible person with sufficient information, time, authority to change the result, documented procedures, and an appeal or correction path.

### Cards, release gates, and continuous responsibility

Data cards and model cards summarize provenance, intended use, evaluation, limitations, and responsibilities.

**Remember:** A limitation becomes actionable only when the team defines how it is detected, communicated, mitigated, monitored, or used to block deployment.

## Universal reasoning checklist

1. Define the task and unit.
2. Separate inputs, operations, outputs, and constraints.
3. Predict before computing.
4. Compare with a baseline or invariant.
5. Test a boundary and preserve failures.
6. State evidence, limitations, and human responsibility.
