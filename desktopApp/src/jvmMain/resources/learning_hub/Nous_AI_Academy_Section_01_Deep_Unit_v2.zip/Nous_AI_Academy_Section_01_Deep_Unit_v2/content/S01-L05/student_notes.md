# Student Notes - S01-L05: Evidence, Reproducibility, and Responsible AI

Complete these notes from memory before reopening the article.

## Big question

What evidence, records, safeguards, and human decisions are required before an AI result becomes a responsible product claim?

## Retrieval notes

### 1. Claims, evidence, and scope

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What information is missing from the claim 'our model achieved 90%'?

**My answer:**

---

### 2. Baselines, metrics, and uncertainty

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why is a baseline part of evidence rather than an optional extra?

**My answer:**

---

### 3. Reproducible experiments

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Name five fields required to reproduce or audit a training run.

**My answer:**

---

### 4. Error analysis and robustness

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What turns an error gallery into an engineering tool?

**My answer:**

---

### 5. Fairness and affected groups

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why can two reasonable fairness metrics disagree?

**My answer:**

---

### 6. Privacy, security, and data minimization

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Give two privacy benefits and two remaining risks of local-only storage.

**My answer:**

---

### 7. Transparency, explainability, and human oversight

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** What makes human oversight real rather than symbolic?

**My answer:**

---

### 8. Cards, release gates, and continuous responsibility

- Definition in my own words:
- Input and output:
- Mechanism:
- Evidence or invariant:
- Boundary case:
- Limitation:
- Connection to another unit:

**Check:** Why should limitations be connected to release tests?

**My answer:**

---

## Final one-page explanation

Explain the entire lesson to a new learner without using unexplained vocabulary. Include one diagram, one worked example, one counterexample, and one honest limitation.
