# Implementation Prompt - Replace Section 1 with the Deep Unit

Implement this package as the real Section 1 experience in the Nous AI Academy desktop Learning Hub.

Preserve `S01`, `S01-L01` through `S01-L05`, and every `NAA-01-xx-xxx` problem ID so existing progress remains connected. Replace only the old short Section 1 content. Do not change Sections 2-20, user accounts, progress, notes, bookmarks, settings, books, or other local content.

Build a professional article lesson page with a sticky table of contents, reading progress, Previous/Next controls, large readable article typography, worked-example cards, misconception warnings, revealable knowledge checks, notes panel, glossary, and accessible keyboard focus. After the article show Practice, Lesson Quiz, Applied Project, Quick Sheet, and PDF actions. Use the warm Nous orange/cream design and restrained animations. Do not copy Khan Academy branding or UI; use only the original Nous content and identity.

Load `section_manifest.json` and each `article_blocks.json`. Multiple-choice tasks are auto-graded. Rubric tasks require a learner response before showing the rubric, then offer Retry, Needs Review, or Mastered. Completion requires eight article units, 64/80 practice mastery, 16/20 quiz mastery or corrections, and project submission. Store everything locally.

Import safely: stage the package, verify `checksums.sha256`, validate all counts and stable IDs, import in one local SQLite transaction, then atomically switch only S01 to the new version. Keep rollback until the real packaged desktop app opens every lesson, PDF, notes, practice, and quiz. Never call a paid/cloud service. Never use the legacy unrestricted ProcessBuilder for code.

Test offline first launch, migration from old S01 progress, notes persistence, assessment scoring, accessibility, PDF Open/Download, corrupted-package rollback, installer launch, and packaged-app restart. Report exact tests and screenshots. Do not declare success from source tests alone.
